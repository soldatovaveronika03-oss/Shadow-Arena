extends Node3D
class_name Bird
# Орёл, кружащий в небе: машет крыльями, наклоняется на виражах.

var center := Vector3.ZERO
var radius := 60.0
var alt := 60.0
var w := 0.2
var a := 0.0
var wing_l: Node3D
var wing_r: Node3D
var t := 0.0

func setup(c: Vector3, r: float, h: float, ang_speed: float) -> void:
	center = c
	radius = r
	alt = h
	w = ang_speed
	a = randf() * TAU
	var brown := Color(0.35, 0.22, 0.12)
	add_child(Fx.sphere(0.22, brown, Vector3.ZERO))
	add_child(Fx.sphere(0.12, Color(0.95, 0.95, 0.92), Vector3(0, 0.05, 0.28)))
	add_child(Fx.cylinder(0.0, 0.05, 0.1, Color(1.0, 0.8, 0.2), Vector3(0, 0.0, 0.42), 4))
	add_child(Fx.box(Vector3(0.3, 0.03, 0.35), brown, Vector3(0, 0, -0.4)))
	wing_l = Fx.pivot(self, Vector3(0.12, 0.05, 0))
	wing_l.add_child(Fx.box(Vector3(1.1, 0.03, 0.45), brown, Vector3(0.55, 0, 0)))
	wing_r = Fx.pivot(self, Vector3(-0.12, 0.05, 0))
	wing_r.add_child(Fx.box(Vector3(1.1, 0.03, 0.45), brown, Vector3(-0.55, 0, 0)))

func _process(delta: float) -> void:
	t += delta
	a += w * delta
	position = center + Vector3(cos(a) * radius, alt + sin(a * 0.7) * 4.0, sin(a) * radius)
	rotation.y = -a
	rotation.z = -0.3
	var f := sin(t * 5.0) * 0.45
	wing_l.rotation.z = f
	wing_r.rotation.z = -f

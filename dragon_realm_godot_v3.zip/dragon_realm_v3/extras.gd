extends Node3D
# Необязательные украшения: облака, орлы, олени, кролики, трава и пыльца.
# Если здесь будет ошибка, игра всё равно запустится без них.

var player: Node3D
var rng: RandomNumberGenerator
var clouds: Array = []
var pollen: CPUParticles3D

func setup(pl: Node3D, r: RandomNumberGenerator) -> void:
	player = pl
	rng = r
	_clouds()
	_birds()
	_critters()
	_grass()
	_pollen()

func _process(delta: float) -> void:
	for c in clouds:
		var cn := c as Node3D
		cn.position.x += delta * 3.0
		if cn.position.x > 700.0:
			cn.position.x = -700.0
	if pollen and player:
		pollen.global_position = player.global_position + Vector3(0, 3.0, 0)

func _clouds() -> void:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(1, 1, 1, 0.93)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	for i in 24:
		var c := Node3D.new()
		c.position = Vector3(rng.randf_range(-700, 700), rng.randf_range(110, 190), rng.randf_range(-700, 300))
		for j in 6:
			var s := SphereMesh.new()
			var rr := rng.randf_range(14.0, 28.0)
			s.radius = rr
			s.height = rr * 1.2
			s.radial_segments = 8
			s.rings = 4
			var mi := MeshInstance3D.new()
			mi.mesh = s
			mi.material_override = m
			mi.position = Vector3(rng.randf_range(-30, 30), rng.randf_range(-4, 6), rng.randf_range(-15, 15))
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			c.add_child(mi)
		add_child(c)
		clouds.append(c)

func _birds() -> void:
	for i in 3:
		var b := Bird.new()
		add_child(b)
		b.setup(Vector3(rng.randf_range(-60, 60), 0, rng.randf_range(-120, 0)), rng.randf_range(50, 110), rng.randf_range(55, 90), rng.randf_range(0.12, 0.25))

func _critters() -> void:
	var none := Color(0, 0, 0, 0)
	for i in 7:
		_add_critter("deer", rng.randf_range(35, 150), none)
	for i in 10:
		_add_critter("rabbit", rng.randf_range(12, 80), none)
	_herd("bison", 4, rng.randf_range(60, 130))
	_herd("bison", 3, rng.randf_range(90, 170))
	_herd("horse", 3, rng.randf_range(40, 110))
	_herd("horse", 3, rng.randf_range(80, 160))

func _find_spot(dist: float) -> Vector3:
	for attempt in 30:
		var a := rng.randf() * TAU
		var x := sin(a) * dist
		var z := cos(a) * dist
		var h := Terrain.height_at(x, z)
		if h > 0.5 and Terrain.normal_at(x, z).y > 0.85:
			return Vector3(x, h, z)
	return Vector3(0, -999.0, 0)

func _add_critter(k: String, dist: float, tint: Color) -> void:
	var p := _find_spot(dist)
	if p.y < -900.0:
		return
	var c := Critter.new()
	c.setup(k, player, p, tint)
	add_child(c)

func _herd(k: String, n: int, dist: float) -> void:
	var base := _find_spot(dist)
	if base.y < -900.0:
		return
	var horse_cols := [Color(0.45, 0.28, 0.15), Color(0.93, 0.93, 0.9), Color(0.12, 0.12, 0.14), Color(0.62, 0.42, 0.22)]
	for j in n:
		var x := base.x + rng.randf_range(-8, 8)
		var z := base.z + rng.randf_range(-8, 8)
		var h := Terrain.height_at(x, z)
		if h < 0.5:
			continue
		var tint := Color(0, 0, 0, 0)
		if k == "horse":
			tint = horse_cols[rng.randi() % horse_cols.size()]
		var c := Critter.new()
		c.setup(k, player, Vector3(x, h, z), tint)
		add_child(c)

func _grass() -> void:
	var mesh := ArrayMesh.new()
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var idx := PackedInt32Array()
	for q in 2:
		var ang := q * PI / 2.0
		var dx := Vector3(cos(ang), 0, sin(ang))
		var base := verts.size()
		verts.append(-dx * 0.3)
		verts.append(dx * 0.3)
		verts.append(dx * 0.07 + Vector3(0, 0.75, 0))
		verts.append(-dx * 0.07 + Vector3(0, 0.75, 0))
		for j in 4:
			norms.append(Vector3.UP)
		idx.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = idx
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)

	var xf := []
	var tries := 0
	while xf.size() < 9000 and tries < 30000:
		tries += 1
		var a := rng.randf() * TAU
		var r := sqrt(rng.randf()) * 160.0
		var x := cos(a) * r
		var z := sin(a) * r
		var h := Terrain.height_at(x, z)
		if h < 0.4 or Terrain.normal_at(x, z).y < 0.85:
			continue
		var s := rng.randf_range(0.7, 1.5)
		var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s * rng.randf_range(0.8, 1.5), s))
		xf.append(Transform3D(b, Vector3(x, h, z)))
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xf.size()
	for i in xf.size():
		mm.set_instance_transform(i, xf[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = Shaders.foliage(Color(0.1, 0.36, 0.1), Color(0.55, 0.8, 0.25), 0.18, 0.0, 0.75, 2.2)
	mmi.visibility_range_end = 140.0
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)

func _pollen() -> void:
	pollen = CPUParticles3D.new()
	pollen.amount = 150
	pollen.lifetime = 8.0
	pollen.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	pollen.emission_box_extents = Vector3(30, 6, 30)
	pollen.direction = Vector3(1, 0.3, 0)
	pollen.spread = 180.0
	pollen.initial_velocity_min = 0.3
	pollen.initial_velocity_max = 0.8
	pollen.gravity = Vector3.ZERO
	var sm := SphereMesh.new()
	sm.radius = 0.05
	sm.height = 0.1
	sm.radial_segments = 4
	sm.rings = 2
	sm.material = Fx.mat(Color(1.0, 0.95, 0.5), 2.0)
	pollen.mesh = sm
	add_child(pollen)
	pollen.emitting = true

class_name Shaders
extends RefCounted
# Шейдеры: качающаяся листва/трава, вода, водопад.

const FOLIAGE := """
shader_type spatial;
render_mode cull_disabled;
uniform vec4 base_color : source_color = vec4(0.1, 0.4, 0.15, 1.0);
uniform vec4 tip_color : source_color = vec4(0.3, 0.65, 0.2, 1.0);
uniform float sway = 0.25;
uniform float speed = 1.6;
uniform float h_min = -1.5;
uniform float h_range = 3.0;
varying float v_h;
void vertex() {
	v_h = clamp((VERTEX.y - h_min) / h_range, 0.0, 1.0);
	float phase = MODEL_MATRIX[3].x * 0.25 + MODEL_MATRIX[3].z * 0.2;
	float s = v_h * v_h * sway;
	VERTEX.x += sin(TIME * speed + phase) * s;
	VERTEX.z += cos(TIME * speed * 0.8 + phase * 1.3) * s * 0.6;
}
void fragment() {
	ALBEDO = mix(base_color.rgb, tip_color.rgb, v_h);
	ROUGHNESS = 0.85;
}
"""

const WATER := """
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back;
uniform vec4 deep : source_color = vec4(0.04, 0.28, 0.45, 1.0);
uniform vec4 shallow : source_color = vec4(0.25, 0.75, 0.8, 1.0);
varying vec3 wpos;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	VERTEX.y += sin(wpos.x * 0.35 + TIME * 1.2) * 0.05 + sin(wpos.z * 0.5 + TIME * 1.6) * 0.05;
}
void fragment() {
	vec2 p = wpos.xz;
	vec3 n = normalize(vec3(sin(p.x * 0.8 + TIME * 1.5) * 0.10 + sin(p.y * 1.7 - TIME) * 0.05, 1.0, cos(p.y * 0.9 + TIME * 1.2) * 0.10));
	NORMAL = normalize((VIEW_MATRIX * vec4(n, 0.0)).xyz);
	float f = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0);
	ALBEDO = mix(deep.rgb, shallow.rgb, f);
	ALPHA = mix(0.78, 0.96, f);
	ROUGHNESS = 0.05;
	METALLIC = 0.1;
	SPECULAR = 0.9;
}
"""

const WATERFALL := """
shader_type spatial;
render_mode cull_disabled, unshaded, blend_mix;
void fragment() {
	float s = sin(UV.y * 60.0 - TIME * 9.0 + sin(UV.x * 18.0 + TIME) * 2.0) * 0.5 + 0.5;
	float edge = smoothstep(0.0, 0.15, UV.x) * smoothstep(1.0, 0.85, UV.x);
	ALBEDO = mix(vec3(0.55, 0.8, 1.0), vec3(1.0), s);
	ALPHA = (0.45 + 0.35 * s) * edge;
}
"""

static var _foliage: Shader
static var _water: Shader
static var _fall: Shader

static func foliage(base: Color, tip: Color, sway: float, h_min: float, h_range: float, speed: float = 1.6) -> ShaderMaterial:
	if _foliage == null:
		_foliage = Shader.new()
		_foliage.code = FOLIAGE
	var m := ShaderMaterial.new()
	m.shader = _foliage
	m.set_shader_parameter("base_color", base)
	m.set_shader_parameter("tip_color", tip)
	m.set_shader_parameter("sway", sway)
	m.set_shader_parameter("speed", speed)
	m.set_shader_parameter("h_min", h_min)
	m.set_shader_parameter("h_range", h_range)
	return m

static func water() -> ShaderMaterial:
	if _water == null:
		_water = Shader.new()
		_water.code = WATER
	var m := ShaderMaterial.new()
	m.shader = _water
	return m

static func waterfall() -> ShaderMaterial:
	if _fall == null:
		_fall = Shader.new()
		_fall.code = WATERFALL
	var m := ShaderMaterial.new()
	m.shader = _fall
	return m

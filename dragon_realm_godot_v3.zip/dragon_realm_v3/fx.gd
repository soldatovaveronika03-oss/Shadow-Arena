class_name Fx
extends RefCounted
# Материалы, примитивы и эффекты.

static func mat(color: Color, emissive: float = 0.0, alpha: float = 1.0, metallic: float = 0.0, rough: float = 0.85) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color.r, color.g, color.b, alpha)
	m.roughness = rough
	m.metallic = metallic
	if emissive > 0.0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emissive
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m

static func mesh_node(mesh: Mesh, color: Color, pos: Vector3 = Vector3.ZERO, emissive: float = 0.0, alpha: float = 1.0, metallic: float = 0.0, rough: float = 0.85) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat(color, emissive, alpha, metallic, rough)
	mi.position = pos
	return mi

static func box(size: Vector3, color: Color, pos: Vector3 = Vector3.ZERO, emissive: float = 0.0, metallic: float = 0.0, rough: float = 0.85) -> MeshInstance3D:
	var m := BoxMesh.new()
	m.size = size
	return mesh_node(m, color, pos, emissive, 1.0, metallic, rough)

static func sphere(radius: float, color: Color, pos: Vector3 = Vector3.ZERO, emissive: float = 0.0, metallic: float = 0.0, rough: float = 0.85) -> MeshInstance3D:
	var m := SphereMesh.new()
	m.radius = radius
	m.height = radius * 2.0
	m.radial_segments = 10
	m.rings = 6
	return mesh_node(m, color, pos, emissive, 1.0, metallic, rough)

static func cylinder(top_r: float, bottom_r: float, height: float, color: Color, pos: Vector3 = Vector3.ZERO, segments: int = 8, emissive: float = 0.0) -> MeshInstance3D:
	var m := CylinderMesh.new()
	m.top_radius = top_r
	m.bottom_radius = bottom_r
	m.height = height
	m.radial_segments = segments
	m.rings = 1
	return mesh_node(m, color, pos, emissive)

static func pivot(parent: Node3D, pos: Vector3 = Vector3.ZERO) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n

static func float_text(parent: Node, pos: Vector3, text: String, color: Color, scale_mul: float = 1.0) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 64
	l.pixel_size = 0.012 * scale_mul
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.outline_size = 14
	l.modulate = color
	l.position = pos
	parent.add_child(l)
	var tw := l.create_tween()
	tw.tween_property(l, "position:y", pos.y + 2.0 * scale_mul, 0.9)
	tw.parallel().tween_property(l, "modulate:a", 0.0, 0.9)
	tw.tween_callback(l.queue_free)

static func burst(parent: Node, pos: Vector3, color: Color, radius: float, duration: float = 0.4) -> void:
	var m := SphereMesh.new()
	m.radius = 1.0
	m.height = 2.0
	m.radial_segments = 16
	m.rings = 8
	var mi := mesh_node(m, color, pos, 2.0, 0.5)
	mi.scale = Vector3.ONE * 0.5
	parent.add_child(mi)
	var tw := mi.create_tween()
	tw.tween_property(mi, "scale", Vector3.ONE * radius, duration)
	tw.parallel().tween_property(mi.material_override, "albedo_color:a", 0.0, duration)
	tw.tween_callback(mi.queue_free)

static func _soft_material() -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m

static func fade_gradient(c: Color) -> Gradient:
	var g := Gradient.new()
	g.set_color(0, c)
	g.set_color(1, Color(c.r, c.g, c.b, 0.0))
	return g

# Разовый всплеск частиц (пыль, искры).
static func puff(parent: Node, pos: Vector3, color: Color, amount: int = 8, size: float = 0.15, speed: float = 2.0, life: float = 0.6) -> void:
	var p := CPUParticles3D.new()
	p.one_shot = true
	p.amount = amount
	p.lifetime = life
	p.explosiveness = 1.0
	p.direction = Vector3.UP
	p.spread = 70.0
	p.initial_velocity_min = speed * 0.5
	p.initial_velocity_max = speed
	p.gravity = Vector3(0, -3.0, 0)
	var sm := SphereMesh.new()
	sm.radius = size
	sm.height = size * 2.0
	sm.radial_segments = 6
	sm.rings = 3
	sm.material = _soft_material()
	p.mesh = sm
	p.color_ramp = fade_gradient(color)
	p.position = pos
	parent.add_child(p)
	p.emitting = true
	parent.get_tree().create_timer(life + 0.5).timeout.connect(p.queue_free)

# Непрерывный источник огня (факелы, дыхание дракона). Вдоль локальной оси +Z.
static func fire_emitter(velocity: float, spread: float, amount: int, size: float) -> CPUParticles3D:
	var p := CPUParticles3D.new()
	p.amount = amount
	p.lifetime = 0.9
	p.direction = Vector3(0, 0, 1)
	p.spread = spread
	p.initial_velocity_min = velocity * 0.7
	p.initial_velocity_max = velocity
	p.gravity = Vector3(0, 3.0, 0)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.5
	var sm := SphereMesh.new()
	sm.radius = size
	sm.height = size * 2.0
	sm.radial_segments = 6
	sm.rings = 3
	var m := _soft_material()
	m.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
	sm.material = m
	p.mesh = sm
	var g := Gradient.new()
	g.set_color(0, Color(1.0, 0.95, 0.5, 0.9))
	g.set_color(1, Color(0.8, 0.1, 0.0, 0.0))
	g.add_point(0.4, Color(1.0, 0.5, 0.1, 0.7))
	p.color_ramp = g
	p.emitting = false
	return p

extends Node3D
class_name Quadruped
# Четвероногая модель с костями: волк, медведь, олень, кролик.
# Анимации: бег/шаг с изгибом лап, покачивание корпуса, дыхание, виляние хвостом,
# укус (челюсть), медведь встаёт на задние лапы при ударе.

const PARAMS := {
	"wolf": {"leg": 0.6, "bl": 0.95, "bw": 0.30, "bh": 0.34, "lw": 0.10, "nl": 0.26, "np": 0.1, "hw": 0.23, "hh": 0.21, "hl": 0.36,
		"tail": 0.55, "tp": 0.45, "tw": 0.12, "stride": 1.9, "amp": 0.8, "ref": 5.5, "ear": 0.14,
		"main": Color(0.5, 0.5, 0.56), "dark": Color(0.2, 0.2, 0.25), "belly": Color(0.85, 0.83, 0.77),
		"hump": false, "antlers": false, "hop": false, "eye": Color(1.0, 0.15, 0.05)},
	"bear": {"leg": 0.62, "bl": 1.35, "bw": 0.8, "bh": 0.8, "lw": 0.26, "nl": 0.3, "np": 0.05, "hw": 0.46, "hh": 0.4, "hl": 0.55,
		"tail": 0.18, "tp": 0.1, "tw": 0.18, "stride": 1.8, "amp": 0.55, "ref": 4.0, "ear": 0.12,
		"main": Color(0.45, 0.27, 0.13), "dark": Color(0.25, 0.14, 0.07), "belly": Color(0.55, 0.37, 0.2),
		"hump": true, "antlers": false, "hop": false, "eye": Color(0.05, 0.02, 0.0)},
	"deer": {"leg": 0.95, "bl": 1.1, "bw": 0.36, "bh": 0.42, "lw": 0.08, "nl": 0.7, "np": 0.9, "hw": 0.18, "hh": 0.2, "hl": 0.38,
		"tail": 0.15, "tp": 0.7, "tw": 0.1, "stride": 1.4, "amp": 0.7, "ref": 8.0, "ear": 0.16,
		"main": Color(0.68, 0.45, 0.22), "dark": Color(0.3, 0.2, 0.12), "belly": Color(0.95, 0.88, 0.76),
		"hump": false, "antlers": true, "hop": false, "eye": Color(0.05, 0.02, 0.0)},
	"rabbit": {"leg": 0.14, "bl": 0.3, "bw": 0.18, "bh": 0.18, "lw": 0.045, "nl": 0.06, "np": 0.2, "hw": 0.12, "hh": 0.11, "hl": 0.16,
		"tail": 0.07, "tp": 0.6, "tw": 0.09, "stride": 1.0, "amp": 0.9, "ref": 5.0, "ear": 0.2,
		"main": Color(0.66, 0.58, 0.46), "dark": Color(0.42, 0.35, 0.28), "belly": Color(0.97, 0.94, 0.9),
		"hump": false, "antlers": false, "hop": true, "eye": Color(0.05, 0.02, 0.0)},
	"tiger": {"leg": 0.85, "bl": 1.7, "bw": 0.62, "bh": 0.65, "lw": 0.2, "nl": 0.35, "np": 0.1, "hw": 0.42, "hh": 0.36, "hl": 0.5,
		"tail": 1.0, "tp": 0.15, "tw": 0.14, "stride": 1.7, "amp": 0.7, "ref": 6.5, "ear": 0.16,
		"main": Color(0.97, 0.97, 1.0), "dark": Color(0.16, 0.16, 0.2), "belly": Color(1.0, 1.0, 1.0),
		"hump": false, "antlers": false, "hop": false, "eye": Color(0.3, 0.75, 1.0), "stripes": true, "tail_tip": Color(0.1, 0.1, 0.12), "paw": Color(0.92, 0.92, 0.95), "snout": Color(0.95, 0.88, 0.9)},
	"bison": {"leg": 0.8, "bl": 1.9, "bw": 0.95, "bh": 1.0, "lw": 0.24, "nl": 0.35, "np": 0.0, "hw": 0.5, "hh": 0.55, "hl": 0.6,
		"tail": 0.6, "tp": 0.2, "tw": 0.1, "stride": 1.7, "amp": 0.5, "ref": 6.0, "ear": 0.15,
		"main": Color(0.3, 0.2, 0.12), "dark": Color(0.15, 0.1, 0.07), "belly": Color(0.38, 0.27, 0.16),
		"hump": true, "hump_size": 0.75, "antlers": false, "hop": false, "eye": Color(0.02, 0.01, 0.0), "horns": true, "shaggy": true},
	"horse": {"leg": 1.05, "bl": 1.5, "bw": 0.5, "bh": 0.55, "lw": 0.12, "nl": 0.8, "np": 0.85, "hw": 0.22, "hh": 0.28, "hl": 0.62,
		"tail": 0.9, "tp": -0.6, "tw": 0.12, "stride": 1.45, "amp": 0.75, "ref": 10.0, "ear": 0.15,
		"main": Color(0.45, 0.28, 0.15), "dark": Color(0.14, 0.1, 0.08), "belly": Color(0.5, 0.32, 0.18),
		"hump": false, "antlers": false, "hop": false, "eye": Color(0.02, 0.01, 0.0), "mane": true, "tail_dark": true},
}

var P: Dictionary
var kind := "wolf"
var body: Node3D
var neck: Node3D
var head: Node3D
var jaw: Node3D
var tail: Node3D
var legs: Array = []
var phase := 0.0
var t := 0.0
var base_y := 0.5
var neck_y := 0.0

func _f(key: String) -> float:
	return float(P[key])

func build(k: String, tint: Color = Color(0, 0, 0, 0)) -> void:
	kind = k
	P = PARAMS[k]
	var L := _f("leg")
	var bl := _f("bl")
	var bw := _f("bw")
	var bh := _f("bh")
	var lw := _f("lw")
	var nl := _f("nl")
	var np := _f("np")
	var hw := _f("hw")
	var hh := _f("hh")
	var hl := _f("hl")
	var main: Color = P["main"]
	var dark: Color = P["dark"]
	var belly: Color = P["belly"]
	if tint.a > 0.0:
		main = tint
		dark = tint.darkened(0.45)
		belly = tint.lightened(0.15)

	var leg_col: Color = P.get("paw", dark)
	var snout_col: Color = P.get("snout", dark)

	base_y = L + bh * 0.3
	body = Node3D.new()
	body.position.y = base_y
	add_child(body)
	body.add_child(Fx.box(Vector3(bw, bh, bl), main))
	body.add_child(Fx.box(Vector3(bw * 1.1, bh * 1.1, bl * 0.42), main, Vector3(0, 0.02, bl * 0.3)))
	body.add_child(Fx.box(Vector3(bw * 0.8, bh * 0.35, bl * 0.85), belly, Vector3(0, -bh * 0.4, 0)))
	if P["hump"]:
		body.add_child(Fx.sphere(bw * float(P.get("hump_size", 0.5)), main, Vector3(0, bh * 0.5, bl * 0.22)))
	if P.get("stripes", false):
		for si2 in 7:
			body.add_child(Fx.box(Vector3(bw * 1.04, bh * 1.04, 0.07), dark, Vector3(0, 0, -bl * 0.42 + si2 * bl * 0.14)))
	if P.get("shaggy", false):
		body.add_child(Fx.box(Vector3(bw * 1.15, bh * 1.08, bl * 0.36), dark, Vector3(0, 0.05, bl * 0.32)))

	# ноги: верхний и нижний суставы
	for fi in 2:
		for si in 2:
			var sd := -1.0 if si == 0 else 1.0
			var hz := bl * 0.36 if fi == 0 else -bl * 0.36
			var up := Fx.pivot(body, Vector3(sd * bw * 0.38, -bh * 0.3, hz))
			var ul := L * 0.5
			up.add_child(Fx.box(Vector3(lw * 1.25, ul, lw * 1.35), main, Vector3(0, -ul * 0.5, 0)))
			var low := Fx.pivot(up, Vector3(0, -ul, 0))
			var ll := L * 0.5
			var ph := L * 0.1
			low.add_child(Fx.box(Vector3(lw, ll, lw), leg_col, Vector3(0, -ll * 0.5, 0)))
			low.add_child(Fx.box(Vector3(lw * 1.15, ph, lw * 1.8), leg_col, Vector3(0, -ll + ph * 0.5, lw * 0.4)))
			legs.append({"up": up, "low": low, "front": fi == 0, "side": sd})

	# шея и голова
	neck = Fx.pivot(body, Vector3(0, bh * 0.2, bl * 0.46))
	neck_y = bh * 0.2
	neck.rotation.x = -np
	neck.add_child(Fx.box(Vector3(bw * 0.62, bh * 0.7, nl), main, Vector3(0, 0, nl * 0.5)))
	if P.get("mane", false):
		neck.add_child(Fx.box(Vector3(0.07, bh * 0.5, nl * 1.05), dark, Vector3(0, bh * 0.4, nl * 0.5)))
	head = Fx.pivot(neck, Vector3(0, 0, nl))
	head.rotation.x = np
	head.add_child(Fx.box(Vector3(hw, hh, hl), main, Vector3(0, 0, hl * 0.35)))
	head.add_child(Fx.box(Vector3(hw * 0.55, hh * 0.5, hl * 0.6), snout_col, Vector3(0, -hh * 0.15, hl * 0.8)))
	head.add_child(Fx.sphere(hw * 0.14, Color(0.05, 0.05, 0.05), Vector3(0, -hh * 0.05, hl * 1.1)))
	var eye_col: Color = P["eye"]
	for sd in [-1.0, 1.0]:
		head.add_child(Fx.sphere(hw * 0.1, eye_col, Vector3(sd * hw * 0.45, hh * 0.2, hl * 0.5), 1.5))
		var ear := Fx.cylinder(0.0, _f("ear") * 0.45, _f("ear"), main, Vector3(sd * hw * 0.35, hh * 0.55 + _f("ear") * 0.4, hl * 0.1), 4)
		ear.rotation_degrees.z = -sd * 12.0
		head.add_child(ear)
	jaw = Fx.pivot(head, Vector3(0, -hh * 0.3, hl * 0.25))
	jaw.add_child(Fx.box(Vector3(hw * 0.5, hh * 0.18, hl * 0.6), belly, Vector3(0, -hh * 0.05, hl * 0.35)))

	if P.get("horns", false):
		var horn := Color(0.92, 0.88, 0.72)
		for sd in [-1.0, 1.0]:
			var hn := Fx.cylinder(0.0, 0.06, 0.4, horn, Vector3(sd * (hw * 0.5 + 0.1), hh * 0.45, hl * 0.1), 5)
			hn.rotation_degrees.z = -sd * 65.0
			head.add_child(hn)

	if P["antlers"]:
		var ant := Color(0.82, 0.76, 0.6)
		for sd in [-1.0, 1.0]:
			var a := Fx.cylinder(0.015, 0.03, 0.5, ant, Vector3(sd * hw * 0.3, hh * 0.5 + 0.22, 0), 5)
			a.rotation_degrees.z = -sd * 18.0
			head.add_child(a)
			for j in 2:
				var br := Fx.cylinder(0.01, 0.02, 0.22, ant, Vector3(sd * (hw * 0.3 + 0.08 + 0.04 * j), hh * 0.5 + 0.3 + 0.12 * j, 0), 4)
				br.rotation_degrees.z = -sd * 50.0
				head.add_child(br)

	# хвост
	var tl := _f("tail")
	var tw := _f("tw")
	tail = Fx.pivot(body, Vector3(0, bh * 0.3, -bl * 0.5))
	tail.rotation.x = _f("tp")
	var tail_col := dark if P.get("tail_dark", false) else main
	var tip_col: Color = P.get("tail_tip", dark if P.get("tail_dark", false) else belly)
	tail.add_child(Fx.box(Vector3(tw, tw, tl), tail_col, Vector3(0, 0, -tl * 0.5)))
	tail.add_child(Fx.sphere(tw * 0.8, tip_col, Vector3(0, 0, -tl)))

func animate(delta: float, speed: float, mode: String, mt: float) -> void:
	t += delta
	var ref := _f("ref")
	var sf := clampf(speed / ref, 0.0, 1.4)
	var moving := speed > 0.4
	if moving:
		phase += delta * speed * _f("stride")
	var A := (_f("amp") * minf(sf * 1.2 + 0.25, 1.2)) if moving else 0.0
	var hop: bool = P["hop"]

	var rise := 0.0
	var open := 0.0
	var neck_extra := 0.0
	if mode == "attack":
		var s := sin(clampf(mt, 0.0, 1.0) * PI)
		open = s
		neck_extra = s * 0.45
		if kind == "bear":
			rise = s

	for i in legs.size():
		var lg: Dictionary = legs[i]
		var up: Node3D = lg["up"]
		var low: Node3D = lg["low"]
		var front: bool = lg["front"]
		var sd: float = lg["side"]
		var off := 0.0
		if hop:
			off = 0.0 if front else 0.35
		elif front:
			off = 0.0 if sd < 0.0 else 0.5
		else:
			off = PI if sd < 0.0 else PI + 0.5
		var ph := phase + off
		var ta := 0.0
		var tl := 0.0
		if moving:
			ta = -A * sin(ph)
			tl = A * 1.3 * maxf(0.0, cos(ph))
		if rise > 0.0:
			ta = (-1.6 * rise) if front else (0.85 * rise)
			tl = (0.4 * rise) if front else 0.0
		up.rotation.x = lerpf(up.rotation.x, ta, 0.35)
		low.rotation.x = lerpf(low.rotation.x, tl, 0.35)

	var bob := (absf(sin(phase)) * 0.06 * sf) if moving else 0.0
	if hop:
		bob = (absf(sin(phase * 0.5)) * 0.25 * sf) if moving else 0.0
	body.position.y = lerpf(body.position.y, base_y + bob + rise * 0.3, 0.3)
	var pitch := (sin(phase * 2.0 + 0.5) * 0.05 * sf) if moving else 0.0
	body.rotation.x = lerpf(body.rotation.x, pitch - rise * 0.85, 0.3)

	neck.position.y = neck_y + sin(t * 2.2) * 0.008
	var np := _f("np")
	neck.rotation.x = lerpf(neck.rotation.x, -np + neck_extra, 0.4)
	var head_bob := (sin(phase * 2.0) * 0.06 * sf) if moving else 0.0
	head.rotation.x = lerpf(head.rotation.x, np - neck_extra * 0.5 + head_bob, 0.4)
	head.rotation.y = lerpf(head.rotation.y, 0.0 if moving else sin(t * 0.7) * 0.3, 0.1)
	jaw.rotation.x = lerpf(jaw.rotation.x, open * 0.9, 0.4)
	var wag := 3.0 + sf * 7.0
	tail.rotation.y = sin(t * wag) * (0.15 + 0.25 * sf)

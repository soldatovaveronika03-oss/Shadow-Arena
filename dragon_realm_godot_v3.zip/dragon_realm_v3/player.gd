extends CharacterBody3D
class_name Player
# Герой Kairon. Скелет из суставов: бёдра, голень, торс, голова, плечи, предплечья,
# плащ из 3 сегментов, меч. Анимации: стойка, бег, 3 удара комбо, взрыв, лечение, рывок.

const GRAVITY := 28.0

var max_hp := 2600.0
var hp := 2600.0
var max_mp := 1000.0
var mp := 1000.0
var level := 15
var speed := 7.5

var move_input := Vector2.ZERO
var cam_yaw := 0.0
var cam_pitch := 0.4
var cam_dist := 9.0
var cam: Camera3D

var model: Node3D
var hips: Node3D
var spine: Node3D
var head_n: Node3D
var thigh: Array[Node3D] = []
var shin: Array[Node3D] = []
var uarm: Array[Node3D] = []
var farm: Array[Node3D] = []
var capes: Array[Node3D] = []
var phase := 0.0
var t_idle := 0.0
var last_step := 1.0

# 0 удар, 1 взрыв, 2 рывок, 3 лечение
var cd := [0.0, 0.0, 0.0, 0.0]
var cd_max := [0.42, 6.0, 3.0, 10.0]
var mp_cost := [0.0, 150.0, 50.0, 200.0]

var state := "idle"
var state_t := 0.0
var state_dur := 0.5
var combo := 0
var since_attack := 99.0
var hit_done := true
var pending := -1
var hurt_t := 0.0
var dash_t := 0.0
var dash_dir := Vector3.ZERO
var dead := false

func _ready() -> void:
	var shape := CapsuleShape3D.new()
	shape.radius = 0.4
	shape.height = 1.8
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position.y = 0.9
	add_child(cs)
	floor_snap_length = 0.7
	floor_max_angle = deg_to_rad(55.0)
	_build_model()
	cam = Camera3D.new()
	cam.top_level = true
	cam.far = 2500.0
	cam.fov = 65.0
	add_child(cam)
	rotation.y = PI
	_update_camera()

func _build_model() -> void:
	model = Node3D.new()
	add_child(model)
	var steel := Color(0.36, 0.44, 0.7)
	var dark := Color(0.1, 0.12, 0.22)
	var blue := Color(0.1, 0.25, 0.95)
	var gold := Color(0.95, 0.75, 0.25)
	var skin := Color(0.9, 0.77, 0.66)
	var hair := Color(0.88, 0.9, 0.98)

	hips = Fx.pivot(model, Vector3(0, 0.95, 0))
	hips.add_child(Fx.box(Vector3(0.44, 0.2, 0.3), dark, Vector3(0, 0.02, 0)))
	hips.add_child(Fx.box(Vector3(0.46, 0.06, 0.32), gold, Vector3(0, 0.12, 0), 0.3, 0.8, 0.3))
	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		var th := Fx.pivot(hips, Vector3(sx * 0.14, -0.05, 0))
		th.add_child(Fx.box(Vector3(0.21, 0.5, 0.24), steel, Vector3(0, -0.25, 0), 0.0, 0.7, 0.35))
		var sh := Fx.pivot(th, Vector3(0, -0.5, 0))
		sh.add_child(Fx.box(Vector3(0.17, 0.42, 0.2), dark, Vector3(0, -0.2, 0)))
		sh.add_child(Fx.box(Vector3(0.2, 0.12, 0.34), steel, Vector3(0, -0.4, 0.06), 0.0, 0.7, 0.35))
		sh.add_child(Fx.sphere(0.1, gold, Vector3(0, 0.0, 0.1), 0.2, 0.8, 0.3))
		thigh.append(th)
		shin.append(sh)

	spine = Fx.pivot(hips, Vector3(0, 0.1, 0))
	spine.add_child(Fx.box(Vector3(0.5, 0.5, 0.3), steel, Vector3(0, 0.27, 0), 0.0, 0.75, 0.3))
	spine.add_child(Fx.box(Vector3(0.42, 0.15, 0.26), dark, Vector3(0, 0.02, 0)))
	spine.add_child(Fx.box(Vector3(0.18, 0.22, 0.02), blue, Vector3(0, 0.33, 0.16), 2.5))
	head_n = Fx.pivot(spine, Vector3(0, 0.58, 0))
	head_n.add_child(Fx.box(Vector3(0.1, 0.1, 0.1), skin, Vector3(0, 0.02, 0)))
	head_n.add_child(Fx.sphere(0.17, skin, Vector3(0, 0.2, 0)))
	head_n.add_child(Fx.sphere(0.19, hair, Vector3(0, 0.25, -0.04)))
	head_n.add_child(Fx.box(Vector3(0.2, 0.28, 0.1), hair, Vector3(0, 0.1, -0.15)))
	for sx in [-1.0, 1.0]:
		head_n.add_child(Fx.sphere(0.027, blue, Vector3(sx * 0.07, 0.2, 0.15), 3.0))

	for i in 2:
		var sx := -1.0 if i == 0 else 1.0
		spine.add_child(Fx.sphere(0.17, steel, Vector3(sx * 0.33, 0.5, 0), 0.0, 0.75, 0.3))
		var ua := Fx.pivot(spine, Vector3(sx * 0.33, 0.5, 0))
		ua.add_child(Fx.box(Vector3(0.13, 0.32, 0.14), steel, Vector3(0, -0.16, 0), 0.0, 0.7, 0.35))
		var fa := Fx.pivot(ua, Vector3(0, -0.32, 0))
		fa.add_child(Fx.box(Vector3(0.12, 0.3, 0.13), dark, Vector3(0, -0.15, 0)))
		fa.add_child(Fx.sphere(0.07, gold, Vector3(0, -0.32, 0), 0.3, 0.8, 0.3))
		uarm.append(ua)
		farm.append(fa)

	# меч в правой руке (индекс 0): клинок вдоль предплечья
	var sw := Fx.pivot(farm[0], Vector3(0, -0.32, 0))
	sw.add_child(Fx.box(Vector3(0.04, 0.18, 0.04), gold, Vector3(0, 0.02, 0)))
	sw.add_child(Fx.box(Vector3(0.3, 0.05, 0.07), gold, Vector3(0, -0.08, 0), 0.4, 0.8, 0.3))
	sw.add_child(Fx.box(Vector3(0.08, 1.0, 0.02), Color(0.45, 0.9, 1.0), Vector3(0, -0.62, 0), 3.0))
	var glow := OmniLight3D.new()
	glow.light_color = Color(0.4, 0.8, 1.0)
	glow.omni_range = 4.0
	glow.light_energy = 0.8
	glow.position = Vector3(0, -0.6, 0)
	sw.add_child(glow)

	# плащ из трёх сегментов
	var parent: Node3D = spine
	var pos := Vector3(0, 0.52, -0.18)
	for i in 3:
		var c := Fx.pivot(parent, pos)
		c.add_child(Fx.box(Vector3(0.52 - 0.03 * i, 0.42, 0.04), blue, Vector3(0, -0.21, 0), 0.4, 0.0, 0.6))
		if i == 2:
			c.add_child(Fx.box(Vector3(0.5, 0.04, 0.05), gold, Vector3(0, -0.42, 0), 1.0))
		capes.append(c)
		parent = c
		pos = Vector3(0, -0.42, 0)

func rotate_cam(rel: Vector2) -> void:
	cam_yaw -= rel.x * 0.006
	cam_pitch = clampf(cam_pitch + rel.y * 0.005, 0.05, 1.2)

func cd_ratio(i: int) -> float:
	return clampf(cd[i] / cd_max[i], 0.0, 1.0)

func _kb() -> Vector2:
	var v := Vector2.ZERO
	if Input.is_physical_key_pressed(KEY_W) or Input.is_physical_key_pressed(KEY_UP):
		v.y += 1.0
	if Input.is_physical_key_pressed(KEY_S) or Input.is_physical_key_pressed(KEY_DOWN):
		v.y -= 1.0
	if Input.is_physical_key_pressed(KEY_A) or Input.is_physical_key_pressed(KEY_LEFT):
		v.x -= 1.0
	if Input.is_physical_key_pressed(KEY_D) or Input.is_physical_key_pressed(KEY_RIGHT):
		v.x += 1.0
	return v

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.physical_keycode:
			KEY_Q: use(1)
			KEY_E: use(2)
			KEY_R: use(3)
	elif event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			cam_dist = clampf(cam_dist - 1.0, 4.0, 25.0)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			cam_dist = clampf(cam_dist + 1.0, 4.0, 25.0)

func _physics_process(delta: float) -> void:
	for i in 4:
		cd[i] = maxf(cd[i] - delta, 0.0)
	since_attack += delta
	hurt_t = maxf(hurt_t - delta, 0.0)
	if not dead:
		hp = minf(max_hp, hp + 12.0 * delta)
		mp = minf(max_mp, mp + 30.0 * delta)
		if Input.is_physical_key_pressed(KEY_SPACE):
			use(0)

	var gh := Terrain.height_at(global_position.x, global_position.z)
	if global_position.y < gh - 0.4:
		global_position.y = gh + 0.05
		velocity.y = 0.0
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0

	if dead:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return

	_update_state(delta)
	var mv := (move_input + _kb()).limit_length(1.0)
	var fwd := Vector3(-sin(cam_yaw), 0.0, -cos(cam_yaw))
	var right := Vector3(cos(cam_yaw), 0.0, -sin(cam_yaw))
	var dir := right * mv.x + fwd * mv.y
	var target_v := dir * speed
	if state == "cast" or state == "attack":
		target_v *= 0.35
	if dash_t > 0.0:
		dash_t -= delta
		target_v = dash_dir * 22.0
		dir = dash_dir
	velocity.x = target_v.x
	velocity.z = target_v.z
	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 12.0 * delta)
	move_and_slide()

func _process(delta: float) -> void:
	_update_camera()
	if not dead:
		_pose(delta)

func _update_camera() -> void:
	var target := global_position + Vector3(0, 1.6, 0)
	var off := Vector3(sin(cam_yaw) * cos(cam_pitch), sin(cam_pitch), cos(cam_yaw) * cos(cam_pitch)) * cam_dist
	var pos := target + off
	pos.y = maxf(pos.y, Terrain.height_at(pos.x, pos.z) + 0.8)
	cam.global_position = pos
	cam.look_at(target, Vector3.UP)

# ---------- состояния ----------

func _update_state(delta: float) -> void:
	if state == "idle":
		return
	state_t += delta
	if state == "attack" and not hit_done and state_t >= 0.28:
		hit_done = true
		_do_attack_hit()
	elif state == "cast" and not hit_done and state_t >= 0.3:
		hit_done = true
		if pending == 1:
			_blast()
		else:
			_heal()
	if state_t >= state_dur:
		state = "idle"

func use(i: int) -> void:
	if dead:
		return
	if cd[i] > 0.0 or mp < mp_cost[i]:
		return
	if state == "cast" and i != 2:
		return
	mp -= mp_cost[i]
	cd[i] = cd_max[i]
	match i:
		0:
			combo = (combo + 1) % 3 if since_attack < 0.9 else 0
			since_attack = 0.0
			state = "attack"
			state_t = 0.0
			state_dur = 0.55
			hit_done = false
		1:
			state = "cast"
			pending = 1
			state_t = 0.0
			state_dur = 0.7
			hit_done = false
		2:
			var mv := (move_input + _kb()).limit_length(1.0)
			var fwd := Vector3(-sin(cam_yaw), 0.0, -cos(cam_yaw))
			var right := Vector3(cos(cam_yaw), 0.0, -sin(cam_yaw))
			var d := right * mv.x + fwd * mv.y
			if d.length() < 0.1:
				d = Vector3(sin(rotation.y), 0.0, cos(rotation.y))
			dash_dir = d.normalized()
			dash_t = 0.25
			state = "dash"
			state_t = 0.0
			state_dur = 0.25
			Fx.puff(get_tree().current_scene, global_position + Vector3(0, 0.2, 0), Color(0.8, 0.7, 0.55, 0.7), 10, 0.2, 3.0, 0.6)
		3:
			state = "cast"
			pending = 3
			state_t = 0.0
			state_dur = 0.85
			hit_done = false

func _flat_dist(e: Enemy) -> float:
	return Vector2(e.global_position.x - global_position.x, e.global_position.z - global_position.z).length()

func _do_attack_hit() -> void:
	var fwd := Vector3(sin(rotation.y), 0.0, cos(rotation.y))
	for n in get_tree().get_nodes_in_group("enemies"):
		var e := n as Enemy
		var d := _flat_dist(e)
		if d - e.hit_radius > 3.4:
			continue
		var to := e.global_position - global_position
		to.y = 0.0
		if d > e.hit_radius + 1.0 and fwd.dot(to.normalized()) < 0.0:
			continue
		var dmg := randf_range(110.0, 170.0) * (1.5 if combo == 2 else 1.0)
		var col := Color(1, 1, 1)
		if randf() < 0.15:
			dmg *= 2.0
			col = Color(1, 0.85, 0.2)
		e.take_damage(dmg, col)
		Fx.puff(get_tree().current_scene, e.global_position + Vector3(0, minf(e.height * 0.5, 1.5), 0), Color(1.0, 0.9, 0.5, 0.9), 8, 0.08, 4.0, 0.35)

func _blast() -> void:
	Fx.burst(get_tree().current_scene, global_position + Vector3(0, 0.5, 0), Color(0.4, 0.6, 1.0), 8.0, 0.45)
	Fx.puff(get_tree().current_scene, global_position + Vector3(0, 0.3, 0), Color(0.6, 0.8, 1.0, 0.9), 30, 0.12, 9.0, 0.7)
	for n in get_tree().get_nodes_in_group("enemies"):
		var e := n as Enemy
		if _flat_dist(e) - e.hit_radius <= 8.0:
			e.take_damage(randf_range(280.0, 360.0), Color(0.6, 0.8, 1.0))

func _heal() -> void:
	hp = minf(max_hp, hp + 800.0)
	Fx.float_text(get_tree().current_scene, global_position + Vector3(0, 2.4, 0), "+800", Color(0.3, 1.0, 0.4))
	Fx.burst(get_tree().current_scene, global_position + Vector3(0, 1.0, 0), Color(0.3, 1.0, 0.4), 2.5, 0.5)
	Fx.puff(get_tree().current_scene, global_position + Vector3(0, 0.2, 0), Color(0.4, 1.0, 0.5, 0.9), 24, 0.09, 4.0, 1.0)

func take_damage(amount: float) -> void:
	if dead or dash_t > 0.0:
		return
	hp -= amount
	hurt_t = 0.3
	Fx.float_text(get_tree().current_scene, global_position + Vector3(0, 2.4, 0), str(int(amount)), Color(1.0, 0.3, 0.3))
	if hp <= 0.0:
		_die()

func _die() -> void:
	dead = true
	hp = 0.0
	var tw := create_tween()
	tw.tween_property(model, "rotation:x", -PI / 2.0, 0.4)
	tw.parallel().tween_property(model, "position:y", 0.25, 0.4)
	get_tree().create_timer(3.0).timeout.connect(_respawn)

func _respawn() -> void:
	dead = false
	hp = max_hp
	mp = max_mp
	position = Vector3(0, Terrain.height_at(0.0, 0.0) + 0.1, 0)
	velocity = Vector3.ZERO
	model.rotation.x = 0.0
	model.position.y = 0.0
	state = "idle"

# ---------- анимация скелета ----------

func _lr(n: Node3D, x: float, y: float, z: float, k: float) -> void:
	n.rotation = n.rotation.lerp(Vector3(x, y, z), k)

func _kf(base: float, w: float, s: float, wind: float, strike: float, rec: float) -> float:
	var v := lerpf(base, w, wind)
	v = lerpf(v, s, strike)
	return lerpf(v, base, rec)

func _pose(delta: float) -> void:
	var sp := Vector2(velocity.x, velocity.z).length()
	var rr := clampf(sp / speed, 0.0, 1.3)
	t_idle += delta
	if sp > 0.3:
		phase += delta * (5.0 + sp * 0.9)
	var k := 1.0 - exp(-delta * 16.0)
	var A := 0.95 * rr
	var s0 := sin(phase)
	var s1 := sin(phase + PI)
	var c0 := cos(phase)
	var c1 := cos(phase + PI)

	var lean := 0.04 + 0.32 * rr
	var thR := -A * s0
	var thL := -A * s1
	var shR := 0.12 + A * 1.2 * maxf(0.0, c0)
	var shL := 0.12 + A * 1.2 * maxf(0.0, c1)
	var uR := Vector3(-0.5 - 0.25 * A * s1, 0.0, 0.05)
	var fR := -1.05 + 0.1 * s1 * rr
	var uLx := -0.2 - 0.9 * A * s0
	var uLz := -0.08
	var fLx := -0.5 - 0.4 * rr
	var spx := lean
	var spy := s0 * 0.2 * rr
	var hipy := -s0 * 0.12 * rr
	var lunge := 0.0
	var flare := rr
	var kk := k

	match state:
		"attack":
			var u := state_t / state_dur
			var wind := smoothstep(0.0, 0.45, u)
			var strike := smoothstep(0.45, 0.65, u)
			var rec := smoothstep(0.75, 1.0, u)
			kk = 1.0 - exp(-delta * 40.0)
			if combo == 0:
				uR = Vector3(_kf(-0.5, -2.6, -0.7, wind, strike, rec), _kf(0.0, 0.2, 0.0, wind, strike, rec), _kf(0.05, -0.3, 0.15, wind, strike, rec))
				fR = _kf(-1.05, -1.3, -0.25, wind, strike, rec)
				spy = _kf(0.0, -0.45, 0.5, wind, strike, rec)
				spx = _kf(lean, -0.1, 0.5, wind, strike, rec)
			elif combo == 1:
				uR = Vector3(_kf(-0.5, -1.5, -1.45, wind, strike, rec), 0.0, _kf(0.05, -1.4, 0.9, wind, strike, rec))
				fR = _kf(-1.05, -0.8, -0.55, wind, strike, rec)
				spy = _kf(0.0, -0.9, 0.9, wind, strike, rec)
			else:
				uR = Vector3(_kf(-0.5, -1.0, -1.55, wind, strike, rec), _kf(0.0, -0.2, 0.1, wind, strike, rec), 0.05)
				fR = _kf(-1.05, -2.1, -0.05, wind, strike, rec)
				spy = _kf(0.0, -0.35, 0.25, wind, strike, rec)
			uLx = _kf(-0.2, -0.6, 0.35, wind, strike, rec)
			lunge = _kf(0.0, -0.05, 0.5 if combo == 2 else 0.35, wind, strike, rec)
			thR = _kf(0.0, 0.3, -0.7, wind, strike, rec)
			thL = _kf(0.0, -0.2, 0.5, wind, strike, rec)
			shR = 0.15
			shL = 0.3
		"cast":
			var u2 := state_t / state_dur
			var up := smoothstep(0.0, 0.4, u2) * (1.0 - smoothstep(0.75, 1.0, u2))
			uR = Vector3(lerpf(uR.x, -2.7, up), 0.0, lerpf(uR.z, -0.35, up))
			uLx = lerpf(uLx, -2.7, up)
			fR = lerpf(fR, -0.3, up)
			fLx = lerpf(fLx, -0.3, up)
			spx = lerpf(spx, -0.2, up)
			if pending == 3:
				uR = Vector3(lerpf(-0.5, -0.4, up), 0.0, lerpf(0.05, -1.4, up))
				uLx = lerpf(-0.2, -0.4, up)
				uLz = lerpf(-0.08, 1.4, up)
		"dash":
			spx = 0.8
			uR = Vector3(0.9, 0.0, 0.1)
			uLx = 0.9
			thR = -1.1
			thL = 0.9
			shR = 0.2
			shL = 1.3
			flare = 1.6
			kk = 1.0 - exp(-delta * 30.0)
	if hurt_t > 0.0:
		spx -= 0.35 * (hurt_t / 0.3)

	_lr(thigh[0], thR, 0.0, 0.0, kk)
	_lr(thigh[1], thL, 0.0, 0.0, kk)
	_lr(shin[0], shR, 0.0, 0.0, kk)
	_lr(shin[1], shL, 0.0, 0.0, kk)
	_lr(uarm[0], uR.x, uR.y, uR.z, kk)
	_lr(farm[0], fR, 0.0, 0.0, kk)
	_lr(uarm[1], uLx, 0.0, uLz, kk)
	_lr(farm[1], fLx, 0.0, 0.0, kk)
	_lr(spine, spx, spy, 0.0, kk)
	_lr(hips, 0.0, hipy, s0 * 0.03 * rr, kk)
	_lr(head_n, -spx * 0.5 + sin(phase * 2.0) * 0.02 * rr, -spy * 0.5, 0.0, kk)
	hips.position.y = lerpf(hips.position.y, 0.95 - 0.03 * rr + absf(c0) * 0.05 * rr, k)
	spine.scale.y = 1.0 + sin(t_idle * 2.0) * 0.012
	model.position.z = lerpf(model.position.z, lunge, kk)
	for i in capes.size():
		var tx := 0.12 + flare * (0.3 + 0.18 * i) + sin(t_idle * 7.0 + i) * 0.05 * flare
		capes[i].rotation.x = lerpf(capes[i].rotation.x, tx, k)
		capes[i].rotation.z = sin(t_idle * 1.5 + i) * 0.03

	if sp > 3.0 and is_on_floor():
		var sgn := signf(s0)
		if sgn != last_step:
			last_step = sgn
			Fx.puff(get_tree().current_scene, global_position + Vector3(0, 0.1, 0), Color(0.75, 0.65, 0.5, 0.6), 4, 0.12, 1.5, 0.5)

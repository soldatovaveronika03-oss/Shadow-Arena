class_name Terrain
extends RefCounted
# Холмистая местность: функция высоты, меш с цветом по вершинам и коллизия.

const SIZE := 960.0
const CELLS := 240
const CASTLE_POS := Vector2(0, -340)
const CASTLE_H := 26.0
const POND_POS := Vector2(38, -28)
const POND_R := 24.0

static var _n1: FastNoiseLite
static var _n2: FastNoiseLite

static func _init_noise() -> void:
	if _n1 != null:
		return
	_n1 = FastNoiseLite.new()
	_n1.seed = 7
	_n1.frequency = 0.004
	_n1.fractal_octaves = 4
	_n2 = FastNoiseLite.new()
	_n2.seed = 21
	_n2.frequency = 0.02

static func height_at(x: float, z: float) -> float:
	_init_noise()
	var d := Vector2(x, z).length()
	var h := _n1.get_noise_2d(x, z) * 16.0 + _n2.get_noise_2d(x, z) * 2.0
	h *= smoothstep(25.0, 90.0, d)
	var dp := Vector2(x - POND_POS.x, z - POND_POS.y).length()
	h = lerpf(h, -3.0, 1.0 - smoothstep(POND_R - 4.0, POND_R + 14.0, dp))
	var dc := Vector2(x - CASTLE_POS.x, z - CASTLE_POS.y).length()
	var edge := pow(maxf(d - 230.0, 0.0) / 250.0, 1.7) * 150.0
	h += edge * (0.7 + absf(_n2.get_noise_2d(x * 0.5, z * 0.5)) * 2.0) * smoothstep(100.0, 190.0, dc)
	h = lerpf(CASTLE_H, h, smoothstep(95.0, 170.0, dc))
	return h

static func normal_at(x: float, z: float) -> Vector3:
	var e := 1.5
	var dx := height_at(x - e, z) - height_at(x + e, z)
	var dz := height_at(x, z - e) - height_at(x, z + e)
	return Vector3(dx, 2.0 * e, dz).normalized()

static func build(parent: Node3D) -> void:
	_init_noise()
	var n := CELLS + 1
	var step := SIZE / float(CELLS)
	var half := SIZE / 2.0
	var heights := PackedFloat32Array()
	heights.resize(n * n)
	var verts := PackedVector3Array()
	verts.resize(n * n)
	for j in n:
		for i in n:
			var x := -half + i * step
			var z := -half + j * step
			var h := height_at(x, z)
			heights[j * n + i] = h
			verts[j * n + i] = Vector3(x, h, z)
	var norms := PackedVector3Array()
	norms.resize(n * n)
	var cols := PackedColorArray()
	cols.resize(n * n)
	for j in n:
		for i in n:
			var hl := heights[j * n + maxi(i - 1, 0)]
			var hr := heights[j * n + mini(i + 1, n - 1)]
			var hd := heights[maxi(j - 1, 0) * n + i]
			var hu := heights[mini(j + 1, n - 1) * n + i]
			var nr := Vector3(hl - hr, 2.0 * step, hd - hu).normalized()
			norms[j * n + i] = nr
			var v := verts[j * n + i]
			var h := v.y
			var nz := _n2.get_noise_2d(v.x * 1.7, v.z * 1.7)
			var c := Color(0.2, 0.5, 0.14).lerp(Color(0.5, 0.72, 0.2), clampf(nz * 0.9 + 0.5, 0.0, 1.0))
			c = Color(0.78, 0.7, 0.45).lerp(c, smoothstep(0.1, 1.0, h))
			if h < -1.5:
				c = Color(0.3, 0.28, 0.2)
			c = c.lerp(Color(0.46, 0.42, 0.4), smoothstep(0.12, 0.3, 1.0 - nr.y))
			c = c.lerp(Color(0.55, 0.55, 0.58), smoothstep(45.0, 75.0, h))
			c = c.lerp(Color(0.95, 0.97, 1.0), smoothstep(95.0, 125.0, h))
			cols[j * n + i] = c
	var idx := PackedInt32Array()
	for j in n - 1:
		for i in n - 1:
			var a := j * n + i
			var b := a + 1
			var c2 := a + n
			var d2 := c2 + 1
			idx.append_array(PackedInt32Array([a, b, c2, b, d2, c2]))
	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_COLOR] = cols
	arrays[Mesh.ARRAY_INDEX] = idx
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	var m := StandardMaterial3D.new()
	m.vertex_color_use_as_albedo = true
	m.roughness = 1.0
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = m
	parent.add_child(mi)

	var hs := HeightMapShape3D.new()
	hs.map_width = n
	hs.map_depth = n
	hs.map_data = heights
	var body := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	cs.shape = hs
	cs.scale = Vector3(step, 1.0, step)
	body.add_child(cs)
	parent.add_child(body)

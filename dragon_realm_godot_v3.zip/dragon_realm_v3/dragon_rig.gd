extends Node3D
class_name DragonRig
# Дракон из dragon.glb со скелетом из отдельных частей: шея, голова, челюсть,
# хвост из 4 сегментов, крылья из 2 суставов, лапы из 2 суставов.

const SCALE_F := 2.5
const NAMES := ["Body", "Neck1", "Neck2", "Head", "Jaw", "Tail1", "Tail2", "Tail3", "Tail4",
	"WingL_In", "WingL_Out", "WingR_In", "WingR_Out",
	"LegFL_Up", "LegFL_Low", "LegFR_Up", "LegFR_Low", "LegHL_Up", "LegHL_Low", "LegHR_Up", "LegHR_Low"]

var root: Node3D
var n := {}
var body_y := 1.3
var t := 0.0
var phase := 0.0
var dying := false
var flap_amt := 0.0

func build() -> bool:
	var ps := load("res://dragon.glb") as PackedScene
	if ps == null:
		return false
	root = ps.instantiate() as Node3D
	if root == null:
		return false
	add_child(root)
	root.scale = Vector3.ONE * SCALE_F
	for nm in NAMES:
		var f := root.find_child(nm, true, false)
		if f != null:
			n[nm] = f
	if not n.has("Body"):
		return false
	body_y = (n["Body"] as Node3D).position.y
	return true

func part(nm: String) -> Node3D:
	if n.has(nm):
		return n[nm] as Node3D
	return null

func _r(nm: String, x: float, y: float, z: float, k: float) -> void:
	if not n.has(nm):
		return
	var nd := n[nm] as Node3D
	nd.rotation = nd.rotation.lerp(Vector3(x, y, z), k)

func animate(delta: float, speed: float, mode: String, mt: float) -> void:
	if n.is_empty():
		return
	t += delta
	var k := 1.0 - exp(-delta * 10.0)
	var moving := speed > 0.4
	if moving:
		phase += delta * speed * 1.1
	var sf := clampf(speed / 3.5, 0.0, 1.0)
	var s := sin(clampf(mt, 0.0, 1.0) * PI)

	var neck1 := -0.1 + sin(t * 1.3) * 0.04
	var neck2 := 0.12 + sin(t * 1.3 + 0.8) * 0.05
	var head_y := sin(t * 0.6) * 0.2
	var jaw := 0.0
	var body_x := sin(phase * 2.0) * 0.02 * sf
	var flap := false
	var fl_base := 0.25
	var tail_gain := 1.0 + sf
	var claw := 0.0

	match mode:
		"roar":
			neck1 = -0.55 * s
			neck2 = -0.4 * s
			jaw = 0.8 * s
			body_x = -0.15 * s
			flap = true
		"breath":
			neck1 = -0.3
			neck2 = 0.15
			jaw = 0.75
			head_y = 0.0
			flap = true
			fl_base = 0.1
			tail_gain = 1.8
		"attack":
			neck1 = 0.55 * s
			neck2 = 0.4 * s
			jaw = 0.9 * s
			claw = s
			tail_gain = 2.2
	if dying:
		neck1 = 0.7
		neck2 = 0.4
		head_y = 0.3
		flap = false
		tail_gain = 0.0

	_r("Neck1", neck1, 0.0, 0.0, k)
	_r("Neck2", neck2, 0.0, 0.0, k)
	_r("Head", 0.0, head_y, 0.0, k)
	_r("Jaw", jaw, 0.0, 0.0, 0.5)
	if n.has("Body"):
		var b := n["Body"] as Node3D
		b.position.y = lerpf(b.position.y, body_y + (absf(sin(phase)) * 0.06 * sf if moving else sin(t * 1.6) * 0.012), 0.3)
		b.rotation = b.rotation.lerp(Vector3(body_x, sin(phase) * 0.04 * sf, 0.0), k)

	for i in 4:
		var ang := sin(t * 1.4 - i * 0.7) * (0.18 + 0.05 * i) * tail_gain
		_r("Tail%d" % (i + 1), 0.0, ang, 0.0, k)

	# крылья
	for side in 2:
		var sg := 1.0 if side == 0 else -1.0
		var sf2 := "L" if side == 0 else "R"
		var inner := -1.1 + sin(t * 1.2) * 0.04
		var outer_z := -0.9
		var outer_y := 0.4
		if flap or flap_amt > 0.05:
			var w := sin(t * 6.0)
			inner = lerpf(inner, fl_base + 0.55 * w, flap_amt)
			outer_z = lerpf(outer_z, 0.1 + 0.35 * sin(t * 6.0 - 0.8), flap_amt)
			outer_y = lerpf(outer_y, 0.0, flap_amt)
		_r("Wing%s_In" % sf2, 0.0, 0.0, sg * inner, k)
		_r("Wing%s_Out" % sf2, 0.0, sg * outer_y, sg * outer_z, k)
	flap_amt = lerpf(flap_amt, 1.0 if flap else 0.0, 0.1)

	# лапы
	var legs := {"LegFL": 0.0, "LegHR": 0.0, "LegFR": PI, "LegHL": PI}
	for nm in legs.keys():
		var ph: float = phase + float(legs[nm])
		var up_x := (-0.5 * sin(ph) * sf) if moving else 0.0
		var low_x := (0.6 * maxf(0.0, cos(ph)) * sf) if moving else 0.0
		if claw > 0.0 and nm.begins_with("LegF"):
			up_x = -1.2 * claw
			low_x = 0.5 * claw
		_r(nm + "_Up", up_x, 0.0, 0.0, 0.35)
		_r(nm + "_Low", low_x, 0.0, 0.0, 0.35)

extends CharacterBody3D
class_name Enemy
# Враги: волк (прыжок и укус), медведь (встаёт на задние лапы), дракон-босс
# (рёв, дыхание огнём, укус и удар лапой).

signal died(enemy)

const KINDS := {
	"wolf": {"name": "Волк", "hp": 300.0, "speed": 5.5, "dmg": 70.0, "aggro": 20.0, "range": 1.8, "cd": 1.2, "radius": 0.6, "height": 1.3, "adur": 0.6, "ahit": 0.35},
	"tiger": {"name": "Белый тигр", "hp": 1200.0, "speed": 6.5, "dmg": 200.0, "aggro": 26.0, "range": 2.6, "cd": 1.4, "radius": 1.2, "height": 2.0, "adur": 0.7, "ahit": 0.4},
	"bear": {"name": "Медведь", "hp": 700.0, "speed": 4.0, "dmg": 140.0, "aggro": 15.0, "range": 2.2, "cd": 1.8, "radius": 1.0, "height": 2.2, "adur": 0.95, "ahit": 0.55},
	"dragon": {"name": "Дракон", "hp": 5000.0, "speed": 3.5, "dmg": 300.0, "aggro": 50.0, "range": 5.0, "cd": 2.5, "radius": 4.5, "height": 9.0, "adur": 1.3, "ahit": 0.6},
}

var kind := "wolf"
var enemy_name := ""
var max_hp := 100.0
var hp := 100.0
var speed := 4.0
var dmg := 50.0
var aggro := 15.0
var atk_range := 2.0
var atk_cd_time := 1.5
var atk_dur := 0.6
var atk_hit := 0.35
var hit_radius := 0.6
var height := 1.3

var player: Player
var home := Vector3.ZERO
var model: Node3D
var rig_q: Quadruped
var rig_d: DragonRig
var fire: CPUParticles3D

var mode := "idle"
var act_t := 0.0
var act_dur := 1.0
var act_hit_t := 0.5
var act_hit := false
var atk_cd := 0.0
var stun_t := 0.0
var roared := false
var breath_cd := 4.0
var breath_tick := 0.0
var wander_dir := Vector3.ZERO
var wander_t := 0.0
var dead := false

func setup(k: String, p: Player, home_pos: Vector3) -> void:
	kind = k
	player = p
	var d: Dictionary = KINDS[k]
	enemy_name = d["name"]
	max_hp = d["hp"]
	hp = max_hp
	speed = d["speed"]
	dmg = d["dmg"]
	aggro = d["aggro"]
	atk_range = d["range"]
	atk_cd_time = d["cd"]
	hit_radius = d["radius"]
	height = d["height"]
	atk_dur = d["adur"]
	atk_hit = d["ahit"]
	home = home_pos
	position = home_pos
	add_to_group("enemies")
	floor_snap_length = 0.8
	floor_max_angle = deg_to_rad(55.0)

	var shape := CapsuleShape3D.new()
	shape.radius = maxf(hit_radius * 0.7, 0.4)
	shape.height = maxf(height, shape.radius * 2.0 + 0.1)
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position.y = shape.height / 2.0
	add_child(cs)

	model = Node3D.new()
	add_child(model)
	if k == "dragon":
		rig_d = DragonRig.new()
		model.add_child(rig_d)
		if not rig_d.build():
			rig_d.queue_free()
			rig_d = null
			model.add_child(Fx.box(Vector3(6, 4, 14), Color(0.2, 0.5, 0.25), Vector3(0, 3, 0)))
		fire = Fx.fire_emitter(16.0, 9.0, 110, 0.55)
		model.add_child(fire)
	else:
		rig_q = Quadruped.new()
		model.add_child(rig_q)
		rig_q.build(k)

func take_damage(amount: float, color: Color = Color(1, 1, 1)) -> void:
	if dead:
		return
	hp -= amount
	aggro = maxf(aggro, 50.0)
	Fx.float_text(get_tree().current_scene, global_position + Vector3(0, height + 0.5, 0), str(int(amount)), color, 1.0 + hit_radius * 0.15)
	if kind != "dragon":
		stun_t = 0.25
		mode = "idle"
	var tw := create_tween()
	tw.tween_property(model, "scale", Vector3.ONE * 1.06, 0.05)
	tw.tween_property(model, "scale", Vector3.ONE, 0.1)
	if hp <= 0.0:
		_die()

func _die() -> void:
	dead = true
	remove_from_group("enemies")
	collision_layer = 0
	if fire:
		fire.emitting = false
	if rig_d:
		rig_d.dying = true
	died.emit(self)
	var tw := create_tween()
	if kind == "dragon":
		tw.tween_property(model, "rotation:z", 0.45, 1.2)
		tw.tween_interval(4.0)
	else:
		tw.tween_property(model, "rotation:z", PI / 2.1, 0.35)
		tw.parallel().tween_property(model, "position:y", 0.3, 0.35)
		tw.tween_interval(1.5)
	tw.tween_property(model, "scale", Vector3.ZERO, 0.5)
	tw.tween_callback(queue_free)

func _start(m: String, dur: float, hit_t: float) -> void:
	mode = m
	act_t = 0.0
	act_dur = dur
	act_hit_t = hit_t
	act_hit = false
	if m == "attack":
		atk_cd = atk_cd_time
	elif m == "breath":
		breath_cd = 9.0
		breath_tick = 0.3
		if fire:
			fire.emitting = true

func _end_action() -> void:
	mode = "idle"
	if fire:
		fire.emitting = false

func _apply_hit() -> void:
	if mode != "attack" or player.dead:
		return
	var to_p := player.global_position - global_position
	to_p.y = 0.0
	if to_p.length() <= atk_range + hit_radius + 1.0:
		player.take_damage(dmg * randf_range(0.9, 1.1))
		Fx.puff(get_tree().current_scene, player.global_position + Vector3(0, 1.2, 0), Color(1.0, 0.2, 0.1, 0.9), 8, 0.08, 4.0, 0.4)

func _physics_process(delta: float) -> void:
	if dead:
		return
	atk_cd = maxf(atk_cd - delta, 0.0)
	breath_cd = maxf(breath_cd - delta, 0.0)
	stun_t = maxf(stun_t - delta, 0.0)
	var gh := Terrain.height_at(global_position.x, global_position.z)
	if global_position.y < gh - 0.4:
		global_position.y = gh + 0.05
		velocity.y = 0.0
	if not is_on_floor():
		velocity.y -= 28.0 * delta
	else:
		velocity.y = 0.0

	var to_p := player.global_position - global_position
	to_p.y = 0.0
	var d := to_p.length()
	var reach := atk_range + hit_radius
	var dir := Vector3.ZERO
	var face := Vector3.ZERO
	var spd := speed

	if stun_t > 0.0:
		pass
	elif mode != "idle":
		act_t += delta
		face = to_p
		if (kind == "wolf" or kind == "tiger") and mode == "attack" and act_t > act_dur * 0.35 and act_t < act_dur * 0.65:
			dir = to_p.normalized()
			spd = speed * 2.4
		if mode == "breath":
			breath_tick -= delta
			if breath_tick <= 0.0:
				breath_tick = 0.3
				var fwd := Vector3(sin(rotation.y), 0.0, cos(rotation.y))
				if not player.dead and d < 26.0 and fwd.dot(to_p.normalized()) > 0.9:
					player.take_damage(dmg * 0.35)
		if not act_hit and act_t >= act_hit_t:
			act_hit = true
			_apply_hit()
		if act_t >= act_dur:
			_end_action()
	elif not player.dead and d < aggro:
		face = to_p
		if kind == "dragon" and not roared:
			roared = true
			_start("roar", 1.5, 99.0)
		elif d > reach * 0.85:
			if kind == "dragon" and breath_cd <= 0.0 and d > 10.0 and d < 28.0:
				_start("breath", 2.4, 99.0)
			else:
				dir = to_p.normalized()
		elif atk_cd <= 0.0:
			_start("attack", atk_dur, atk_hit)
	else:
		wander_t -= delta
		if wander_t <= 0.0:
			wander_t = randf_range(2.0, 4.0)
			if randf() < 0.4:
				wander_dir = Vector3.ZERO
			else:
				var a := randf() * TAU
				wander_dir = Vector3(sin(a), 0.0, cos(a))
			var to_home := home - global_position
			to_home.y = 0.0
			if to_home.length() > 15.0:
				wander_dir = to_home.normalized()
		dir = wander_dir * 0.4
		face = dir

	velocity.x = dir.x * spd
	velocity.z = dir.z * spd
	if face.length() > 0.01:
		rotation.y = lerp_angle(rotation.y, atan2(face.x, face.z), 8.0 * delta)
	move_and_slide()

	var hs := Vector2(velocity.x, velocity.z).length()
	var mt := clampf(act_t / act_dur, 0.0, 1.0) if mode != "idle" else 0.0
	if rig_q:
		rig_q.animate(delta, hs, mode, mt)
	if rig_d:
		rig_d.animate(delta, hs, mode, mt)
		_update_fire()

func _update_fire() -> void:
	if fire == null:
		return
	var head := rig_d.part("Head")
	if head == null:
		return
	var fwd := Vector3(sin(rotation.y), -0.12, cos(rotation.y)).normalized()
	fire.global_position = head.global_position + fwd * 1.8 + Vector3(0, -0.5, 0)
	fire.look_at(fire.global_position - fwd)

extends Node3D
class_name Critter
# Мирные животные: олени и кролики. Гуляют и убегают от героя.

var kind := "deer"
var player: Node3D
var rig: Quadruped
var wander_dir := Vector3.ZERO
var wander_t := 0.0
var cur_speed := 0.0
var flee_r := 14.0
var walk_speed := 1.5
var run_speed := 8.0

func setup(k: String, pl: Node3D, pos: Vector3, tint: Color = Color(0, 0, 0, 0)) -> void:
	kind = k
	player = pl
	position = pos
	match k:
		"rabbit":
			flee_r = 9.0
			walk_speed = 1.0
			run_speed = 6.0
		"bison":
			flee_r = 10.0
			walk_speed = 1.2
			run_speed = 7.0
		"horse":
			flee_r = 16.0
			walk_speed = 1.8
			run_speed = 11.0
	rig = Quadruped.new()
	add_child(rig)
	rig.build(k, tint)

func _process(delta: float) -> void:
	var to_p := player.global_position - global_position
	to_p.y = 0.0
	var d := to_p.length()
	var dir := Vector3.ZERO
	var target := 0.0
	if d < flee_r and d > 0.01:
		dir = -to_p.normalized()
		target = run_speed
	else:
		wander_t -= delta
		if wander_t <= 0.0:
			wander_t = randf_range(2.0, 5.0)
			if randf() < 0.5:
				wander_dir = Vector3.ZERO
			else:
				var a := randf() * TAU
				wander_dir = Vector3(sin(a), 0.0, cos(a))
		dir = wander_dir
		target = walk_speed if dir.length() > 0.1 else 0.0
	cur_speed = lerpf(cur_speed, target, 0.1)
	if dir.length() > 0.01:
		var np := global_position + dir * cur_speed * delta
		var h := Terrain.height_at(np.x, np.z)
		if h > 0.0 and absf(np.x) < 380.0 and absf(np.z) < 380.0 and Terrain.normal_at(np.x, np.z).y > 0.8:
			global_position = Vector3(np.x, h, np.z)
		else:
			wander_dir = -wander_dir
			cur_speed = 0.0
		rotation.y = lerp_angle(rotation.y, atan2(dir.x, dir.z), 6.0 * delta)
	else:
		position.y = Terrain.height_at(global_position.x, global_position.z)
	rig.animate(delta, cur_speed, "idle", 0.0)

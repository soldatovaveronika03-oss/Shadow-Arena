extends Control
class_name Hud
# Интерфейс. Все размеры берутся из get_viewport_rect(), поэтому джойстик
# и кнопки всегда видны. Сначала рисуется управление, потом остальное.

const BTN_LABELS := ["Удар", "Взрыв", "Рывок", "Лечение"]

var player: Player
var font: Font
var ui := 1.0
var vs := Vector2(1280, 720)

var stick_vec := Vector2.ZERO
var stick_touch := -1
var cam_touch := -1
var btn_touches := {}

var quest_title := ""
var quest_line := ""
var quest_progress := ""
var quest_done := false
var banner := ""
var banner_t := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	font = ThemeDB.fallback_font
	_refresh_size()

func _refresh_size() -> void:
	vs = get_viewport_rect().size
	ui = maxf(vs.y, 1.0) / 720.0
	position = Vector2.ZERO
	size = vs

func set_quest(title: String, line: String, progress: String, done: bool) -> void:
	quest_title = title
	quest_line = line
	quest_progress = progress
	quest_done = done

func show_banner(text: String, seconds: float) -> void:
	banner = text
	banner_t = seconds

func _stick_center() -> Vector2:
	return Vector2(170.0 * ui, vs.y - 150.0 * ui)

func _stick_radius() -> float:
	return 95.0 * ui

func _btn_pos(i: int) -> Vector2:
	match i:
		0: return Vector2(vs.x - 110.0 * ui, vs.y - 120.0 * ui)
		1: return Vector2(vs.x - 250.0 * ui, vs.y - 75.0 * ui)
		2: return Vector2(vs.x - 215.0 * ui, vs.y - 190.0 * ui)
	return Vector2(vs.x - 110.0 * ui, vs.y - 250.0 * ui)

func _btn_radius(i: int) -> float:
	return (64.0 if i == 0 else 44.0) * ui

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position, event.relative)

func _press(idx: int, pos: Vector2) -> void:
	for i in 4:
		if pos.distance_to(_btn_pos(i)) <= _btn_radius(i) * 1.25:
			btn_touches[idx] = i
			if player:
				player.use(i)
			return
	if stick_touch == -1 and pos.distance_to(_stick_center()) <= _stick_radius() * 1.6:
		stick_touch = idx
		_update_stick(pos)
		return
	if cam_touch == -1 and pos.x > vs.x * 0.3:
		cam_touch = idx

func _release(idx: int) -> void:
	if idx == stick_touch:
		stick_touch = -1
		stick_vec = Vector2.ZERO
	if idx == cam_touch:
		cam_touch = -1
	btn_touches.erase(idx)

func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == stick_touch:
		_update_stick(pos)
	elif idx == cam_touch and player:
		player.rotate_cam(rel)

func _update_stick(pos: Vector2) -> void:
	var v := ((pos - _stick_center()) / _stick_radius()).limit_length(1.0)
	if v.length() < 0.12:
		v = Vector2.ZERO
	stick_vec = v

func _process(delta: float) -> void:
	_refresh_size()
	banner_t = maxf(banner_t - delta, 0.0)
	if player:
		player.move_input = Vector2(stick_vec.x, -stick_vec.y)
		for b in btn_touches.values():
			if b == 0:
				player.use(0)
	queue_redraw()

# ---------- рисование ----------

func _txt(text: String, pos: Vector2, fsize: int, col: Color = Color.WHITE, center: bool = false) -> void:
	var p := pos
	if center:
		p.x -= font.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fsize).x / 2.0
	draw_string_outline(font, p, text, HORIZONTAL_ALIGNMENT_LEFT, -1, fsize, 5, Color(0, 0, 0, 0.85))
	draw_string(font, p, text, HORIZONTAL_ALIGNMENT_LEFT, -1, fsize, col)

func _bar(rect: Rect2, ratio: float, col: Color, text: String) -> void:
	draw_rect(rect, Color(0, 0, 0, 0.6))
	draw_rect(Rect2(rect.position, Vector2(rect.size.x * clampf(ratio, 0.0, 1.0), rect.size.y)), col)
	draw_rect(rect, Color(1, 1, 1, 0.5), false, 2.0 * ui)
	if text != "":
		var fs := int(rect.size.y * 0.75)
		_txt(text, rect.position + rect.size / 2.0 + Vector2(0, fs * 0.35), fs, Color.WHITE, true)

func _draw() -> void:
	if player == null or font == null:
		return
	_draw_controls()
	_draw_top_left()
	_draw_compass()
	_draw_minimap()
	_draw_enemy_bars()
	if not DisplayServer.is_touchscreen_available():
		_txt("WASD - движение, мышь (зажать и тянуть) - камера, колесо - zoom, Space - удар, Q / E / R - умения", Vector2(vs.x / 2.0, vs.y - 14.0 * ui), int(14 * ui), Color(1, 1, 1, 0.7), true)
	if banner_t > 0.0:
		_txt(banner, Vector2(vs.x / 2.0, vs.y * 0.3), int(40 * ui), Color(1, 0.9, 0.4, minf(banner_t, 1.0)), true)
	if player.dead:
		draw_rect(Rect2(Vector2.ZERO, vs), Color(0.3, 0, 0, 0.4))
		_txt("Вы погибли", Vector2(vs.x / 2.0, vs.y / 2.0), int(52 * ui), Color(1, 0.4, 0.4), true)

func _draw_controls() -> void:
	var sc := _stick_center()
	var sr := _stick_radius()
	draw_circle(sc, sr, Color(0.05, 0.08, 0.15, 0.55))
	draw_arc(sc, sr, 0.0, TAU, 48, Color(1, 1, 1, 0.6), 4.0 * ui)
	draw_circle(sc + stick_vec * sr * 0.6, 38.0 * ui, Color(0.8, 0.85, 0.95, 0.85))
	var held := btn_touches.values()
	for i in 4:
		var bp := _btn_pos(i)
		var br := _btn_radius(i)
		var pressed := held.has(i)
		draw_circle(bp, br, Color(0.05, 0.1, 0.25, 0.8))
		draw_arc(bp, br, 0.0, TAU, 40, Color(0.45, 0.8, 1.0, 1.0 if pressed else 0.9), (7.0 if pressed else 4.0) * ui)
		if player.mp < player.mp_cost[i]:
			draw_circle(bp, br, Color(0.5, 0, 0, 0.4))
		var ratio := player.cd_ratio(i)
		if ratio > 0.0:
			draw_arc(bp, br * 0.5, -PI / 2.0, -PI / 2.0 + TAU * ratio, 24, Color(0, 0, 0, 0.65), br)
		_txt(BTN_LABELS[i], bp + Vector2(0, 7.0 * ui), int((24 if i == 0 else 16) * ui), Color.WHITE, true)
		var cost: float = player.mp_cost[i]
		if cost > 0.0:
			_txt(str(int(cost)), bp + Vector2(0, br * 0.78), int(13 * ui), Color(0.5, 0.75, 1.0), true)

func _draw_top_left() -> void:
	var pc := Vector2(62, 62) * ui
	draw_circle(pc, 46.0 * ui, Color(0.08, 0.12, 0.25, 0.9))
	draw_circle(pc + Vector2(0, -8) * ui, 17.0 * ui, Color(0.88, 0.9, 0.98))
	draw_circle(pc + Vector2(0, 26) * ui, 22.0 * ui, Color(0.2, 0.3, 0.7))
	draw_arc(pc, 46.0 * ui, 0.0, TAU, 40, Color(0.4, 0.65, 1.0), 4.0 * ui)
	var bc := pc + Vector2(34, 34) * ui
	draw_circle(bc, 17.0 * ui, Color(0.05, 0.08, 0.18))
	draw_arc(bc, 17.0 * ui, 0.0, TAU, 24, Color(0.9, 0.9, 1.0), 2.0 * ui)
	_txt(str(player.level), bc + Vector2(0, 7) * ui, int(20 * ui), Color.WHITE, true)
	_txt("Kairon", Vector2(122, 34) * ui, int(24 * ui))
	_bar(Rect2(Vector2(112, 42) * ui, Vector2(300, 26) * ui), player.hp / player.max_hp, Color(0.8, 0.1, 0.1), "%d / %d" % [int(player.hp), int(player.max_hp)])
	_bar(Rect2(Vector2(112, 72) * ui, Vector2(300, 20) * ui), player.mp / player.max_mp, Color(0.15, 0.4, 0.95), "%d / %d" % [int(player.mp), int(player.max_mp)])
	var qr := Rect2(Vector2(14, 118) * ui, Vector2(310, 84) * ui)
	draw_rect(qr, Color(0, 0, 0, 0.45))
	var ic := qr.position + Vector2(30, 28) * ui
	draw_circle(ic, 16.0 * ui, Color(0.2, 0.7, 0.3) if quest_done else Color(0.15, 0.5, 0.95))
	_txt("+" if quest_done else "!", ic + Vector2(0, 8) * ui, int(22 * ui), Color.WHITE, true)
	_txt(quest_title, qr.position + Vector2(60, 32) * ui, int(22 * ui))
	_txt(quest_line, qr.position + Vector2(60, 64) * ui, int(18 * ui), Color(0.9, 0.9, 0.9))
	_txt(quest_progress, qr.position + Vector2(240, 64) * ui, int(18 * ui), Color(1, 0.9, 0.5))

func _draw_compass() -> void:
	var heading := -player.cam_yaw
	var half := 240.0 * ui
	var cx := vs.x / 2.0
	draw_rect(Rect2(cx - half, 14.0 * ui, half * 2.0, 28.0 * ui), Color(0, 0, 0, 0.25))
	for k in 24:
		var a := k * PI / 12.0
		var rel := wrapf(a - heading, -PI, PI)
		if absf(rel) < PI * 0.5:
			var x := cx + rel / (PI * 0.5) * half
			draw_line(Vector2(x, 36.0 * ui), Vector2(x, 42.0 * ui), Color(1, 1, 1, 0.5), 2.0 * ui)
	var names := ["N", "E", "S", "W"]
	var angs := [0.0, PI / 2.0, PI, -PI / 2.0]
	for i in 4:
		var ang: float = angs[i]
		var rel2 := wrapf(ang - heading, -PI, PI)
		if absf(rel2) < PI * 0.5:
			var x2 := cx + rel2 / (PI * 0.5) * half
			var col := Color(1, 0.85, 0.3) if i == 0 else Color.WHITE
			_txt(names[i], Vector2(x2, 36.0 * ui), int(22 * ui), col, true)
	draw_colored_polygon(PackedVector2Array([Vector2(cx - 7 * ui, 46 * ui), Vector2(cx + 7 * ui, 46 * ui), Vector2(cx, 58 * ui)]), Color(1, 0.85, 0.3))
	var nearest := 1.0e9
	for n in get_tree().get_nodes_in_group("enemies"):
		var e := n as Enemy
		nearest = minf(nearest, player.global_position.distance_to(e.global_position))
	if nearest < 1.0e8:
		_txt("%d м" % int(nearest), Vector2(cx, 82.0 * ui), int(20 * ui), Color.WHITE, true)

func _draw_minimap() -> void:
	var t := Time.get_time_dict_from_system()
	_txt("%02d:%02d" % [t["hour"], t["minute"]], Vector2(vs.x - 225.0 * ui, 36.0 * ui), int(24 * ui))
	draw_circle(Vector2(vs.x - 255.0 * ui, 26.0 * ui), 9.0 * ui, Color(1, 0.85, 0.2))
	var mc := Vector2(vs.x - 100.0 * ui, 125.0 * ui)
	var mr := 84.0 * ui
	draw_circle(mc, mr, Color(0.12, 0.25, 0.12, 0.85))
	draw_arc(mc, mr, 0.0, TAU, 48, Color(0.75, 0.8, 0.9), 4.0 * ui)
	var sc := mr / 70.0
	var p := player.global_position
	for n in get_tree().get_nodes_in_group("enemies"):
		var e := n as Enemy
		var off := Vector2(e.global_position.x - p.x, e.global_position.z - p.z) * sc
		if off.length() > mr - 6.0 * ui:
			continue
		var boss := e.kind == "dragon"
		draw_circle(mc + off, (7.0 if boss else 3.5) * ui, Color(1, 0.55, 0.1) if boss else Color(0.95, 0.2, 0.2))
	var f := Vector2(sin(player.rotation.y), cos(player.rotation.y))
	var perp := Vector2(-f.y, f.x)
	draw_colored_polygon(PackedVector2Array([mc + f * 11.0 * ui, mc - f * 7.0 * ui + perp * 7.0 * ui, mc - f * 7.0 * ui - perp * 7.0 * ui]), Color(0.4, 0.8, 1.0))

func _draw_enemy_bars() -> void:
	var cam := player.cam
	if cam == null:
		return
	for n in get_tree().get_nodes_in_group("enemies"):
		var e := n as Enemy
		var wp := e.global_position + Vector3(0, e.height + 0.6, 0)
		if cam.is_position_behind(wp):
			continue
		var d := cam.global_position.distance_to(wp)
		var boss := e.kind == "dragon"
		if not boss and (d > 60.0 or (e.hp >= e.max_hp and d > 30.0)):
			continue
		var sp := cam.unproject_position(wp)
		var bw := (130.0 if boss else 64.0) * ui
		var rect := Rect2(sp - Vector2(bw / 2.0, 0), Vector2(bw, 8.0 * ui))
		draw_rect(rect, Color(0, 0, 0, 0.7))
		draw_rect(Rect2(rect.position, Vector2(bw * clampf(e.hp / e.max_hp, 0.0, 1.0), rect.size.y)), Color(0.9, 0.15, 0.15))
		_txt(e.enemy_name, sp + Vector2(0, -6.0 * ui), int(16 * ui), Color.WHITE, true)

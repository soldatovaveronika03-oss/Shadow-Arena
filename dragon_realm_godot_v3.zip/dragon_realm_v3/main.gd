extends Node3D
# Главная сцена: местность, вода, лес, скалы, цветы, замок, парящие острова
# с водопадами, портал, костры, герой, враги, босс и интерфейс.

var player: Player
var hud: Hud
var rng := RandomNumberGenerator.new()
var kills := 0
var stage := 0
var orbit: Node3D

func _ready() -> void:
	rng.seed = 20261121
	_build_environment()
	Terrain.build(self)
	_build_water()
	_build_forest()
	_build_castle()
	_build_sky_islands()
	_build_braziers()

	player = Player.new()
	player.position = Vector3(0, Terrain.height_at(0.0, 0.0) + 0.1, 0)
	add_child(player)

	var layer := CanvasLayer.new()
	add_child(layer)
	hud = Hud.new()
	hud.player = player
	layer.add_child(hud)

	for i in 6:
		_spawn("wolf")
	for i in 3:
		_spawn("bear")
	for i in 2:
		_spawn("tiger")
	var dp := Vector3(-60, 0, -95)
	dp.y = Terrain.height_at(dp.x, dp.z) + 0.1
	_spawn("dragon", dp)

	var ex = load("res://extras.gd")
	if ex != null:
		var inst = ex.new()
		add_child(inst)
		if inst.has_method("setup"):
			inst.setup(player, rng)

	_update_quest()
	hud.show_banner("Исследуйте мир", 3.0)

func _process(delta: float) -> void:
	if orbit:
		orbit.rotation.z += delta * 0.8

# ---------- враги и задания ----------

func _spot(rmin: float, rmax: float) -> Vector3:
	for attempt in 40:
		var a := rng.randf() * TAU
		var r := rng.randf_range(rmin, rmax)
		var x := sin(a) * r
		var z := cos(a) * r
		var h := Terrain.height_at(x, z)
		if h < 0.4:
			continue
		if Terrain.normal_at(x, z).y < 0.82:
			continue
		if Vector2(x - Terrain.CASTLE_POS.x, z - Terrain.CASTLE_POS.y).length() < 180.0:
			continue
		return Vector3(x, h, z)
	return Vector3(rmin, Terrain.height_at(rmin, 0.0), 0.0)

func _spawn(kind: String, pos: Variant = null) -> void:
	var p: Vector3
	if pos == null:
		if kind == "tiger":
			p = _spot(60.0, 140.0)
		else:
			p = _spot(22.0, 90.0)
		p.y += 0.1
	else:
		p = pos
	var e := Enemy.new()
	e.setup(kind, player, p)
	e.died.connect(_on_enemy_died)
	add_child(e)

func _on_enemy_died(e: Enemy) -> void:
	if e.kind == "dragon":
		stage = 2
		hud.show_banner("Дракон повержен! Задание выполнено", 5.0)
	else:
		get_tree().create_timer(20.0).timeout.connect(_spawn.bind(e.kind))
		if stage == 0:
			kills += 1
			if kills >= 3:
				stage = 1
				hud.show_banner("Задание выполнено! Найдите дракона", 5.0)
	_update_quest()

func _update_quest() -> void:
	match stage:
		0: hud.set_quest("Исследование мира", "Победите 3 врагов", "%d / 3" % mini(kills, 3), false)
		1: hud.set_quest("Охота на дракона", "Победите дракона", "0 / 1", false)
		_: hud.set_quest("Мир спасён", "Дракон повержен", "1 / 1", true)

# ---------- окружение ----------

func _build_environment() -> void:
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.16, 0.38, 0.85)
	sky_mat.sky_horizon_color = Color(0.7, 0.85, 1.0)
	sky_mat.ground_horizon_color = Color(0.7, 0.85, 1.0)
	sky_mat.ground_bottom_color = Color(0.3, 0.4, 0.35)
	sky_mat.sun_angle_max = 25.0
	var sky := Sky.new()
	sky.sky_material = sky_mat
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.fog_enabled = true
	env.fog_light_color = Color(0.72, 0.86, 1.0)
	env.fog_density = 0.0012
	env.glow_enabled = true
	env.glow_intensity = 0.9
	env.glow_bloom = 0.08
	env.adjustment_enabled = true
	env.adjustment_saturation = 1.25
	env.adjustment_contrast = 1.06
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-42, -35, 0)
	sun.light_color = Color(1.0, 0.95, 0.85)
	sun.light_energy = 1.5
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 120.0
	add_child(sun)

func _build_water() -> void:
	var plane := PlaneMesh.new()
	plane.size = Vector2(110, 110)
	plane.subdivide_width = 40
	plane.subdivide_depth = 40
	var mi := MeshInstance3D.new()
	mi.mesh = plane
	mi.material_override = Shaders.water()
	mi.position = Vector3(Terrain.POND_POS.x, -0.5, Terrain.POND_POS.y)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

func _multi(mesh: Mesh, mat: Material, xforms: Array) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	mmi.material_override = mat
	add_child(mmi)

func _cyl_mesh(top_r: float, bottom_r: float, h: float, seg: int) -> CylinderMesh:
	var m := CylinderMesh.new()
	m.top_radius = top_r
	m.bottom_radius = bottom_r
	m.height = h
	m.radial_segments = seg
	m.rings = 1
	return m

func _pick_species(h: float) -> String:
	if h > 14.0 and rng.randf() < 0.75:
		return "pine"
	var r := rng.randf()
	if r < 0.25:
		return "oak"
	if r < 0.5:
		return "ash"
	if r < 0.7:
		return "birch"
	if r < 0.88:
		return "maple"
	return "pine"

func _sph_mesh() -> SphereMesh:
	var m := SphereMesh.new()
	m.radius = 1.0
	m.height = 2.0
	m.radial_segments = 8
	m.rings = 5
	return m

# Преобразование части кроны: sc.x должно равняться sc.z
func _part(b: Basis, p: Vector3, off: Vector3, sc: Vector3) -> Transform3D:
	return Transform3D(b.scaled(sc), p + b * off)

func _build_forest() -> void:
	var L := {}
	for key in ["oak_t", "oak_c", "ash_t", "ash_c", "pine_t", "pine_1", "pine_2", "pine_3", "birch_t", "birch_c", "maple_t", "maple_c"]:
		L[key] = []
	for i in 250:
		var p := _spot(14.0, 220.0)
		var sp := _pick_species(p.y)
		var s := rng.randf_range(0.8, 1.6)
		var b := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s, s, s))
		var cr := 0.3
		var ch := 3.0
		match sp:
			"oak":
				L["oak_t"].append(Transform3D(b, p + b * Vector3(0, 1.3, 0)))
				L["oak_c"].append(_part(b, p, Vector3(0, 3.9, 0), Vector3(2.8, 2.2, 2.8)))
				L["oak_c"].append(_part(b, p, Vector3(1.7, 3.2, 0.8), Vector3(1.7, 1.4, 1.7)))
				L["oak_c"].append(_part(b, p, Vector3(-1.5, 3.4, -0.9), Vector3(1.6, 1.3, 1.6)))
				L["oak_c"].append(_part(b, p, Vector3(0.6, 4.9, -0.6), Vector3(1.5, 1.2, 1.5)))
				cr = 0.5
				ch = 2.6
			"ash":
				L["ash_t"].append(Transform3D(b, p + b * Vector3(0, 2.3, 0)))
				L["ash_c"].append(_part(b, p, Vector3(0, 6.0, 0), Vector3(1.5, 2.6, 1.5)))
				L["ash_c"].append(_part(b, p, Vector3(0.5, 4.4, 0.3), Vector3(1.1, 1.3, 1.1)))
				cr = 0.3
				ch = 4.6
			"birch":
				L["birch_t"].append(Transform3D(b, p + b * Vector3(0, 2.2, 0)))
				L["birch_c"].append(_part(b, p, Vector3(0, 5.4, 0), Vector3(1.2, 2.0, 1.2)))
				L["birch_c"].append(_part(b, p, Vector3(0.5, 4.1, 0.3), Vector3(0.9, 1.2, 0.9)))
				cr = 0.2
				ch = 4.4
			"maple":
				L["maple_t"].append(Transform3D(b, p + b * Vector3(0, 1.5, 0)))
				L["maple_c"].append(_part(b, p, Vector3(0, 4.5, 0), Vector3(2.4, 2.0, 2.4)))
				L["maple_c"].append(_part(b, p, Vector3(1.3, 3.7, 0.5), Vector3(1.5, 1.3, 1.5)))
				L["maple_c"].append(_part(b, p, Vector3(-1.1, 3.9, -0.8), Vector3(1.4, 1.2, 1.4)))
				cr = 0.35
				ch = 3.0
			_:
				L["pine_t"].append(Transform3D(b, p + b * Vector3(0, 1.8, 0)))
				L["pine_1"].append(Transform3D(b, p + b * Vector3(0, 3.7, 0)))
				L["pine_2"].append(Transform3D(b, p + b * Vector3(0, 5.6, 0)))
				L["pine_3"].append(Transform3D(b, p + b * Vector3(0, 7.3, 0)))
				cr = 0.28
				ch = 3.6
		var body := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var shape := CylinderShape3D.new()
		shape.radius = cr * s
		shape.height = ch * s
		cs.shape = shape
		body.add_child(cs)
		body.position = p + Vector3(0, ch * s / 2.0, 0)
		add_child(body)

	var sph := _sph_mesh()
	# дуб: толстый ствол, широкая тёмно-зелёная крона
	_multi(_cyl_mesh(0.32, 0.5, 2.6, 7), Fx.mat(Color(0.33, 0.21, 0.11)), L["oak_t"])
	_multi(sph, Shaders.foliage(Color(0.08, 0.3, 0.08), Color(0.38, 0.66, 0.18), 0.22, -1.0, 2.0), L["oak_c"])
	# ясень: высокий стройный, светлая овальная крона
	_multi(_cyl_mesh(0.16, 0.3, 4.6, 6), Fx.mat(Color(0.42, 0.38, 0.32)), L["ash_t"])
	_multi(sph, Shaders.foliage(Color(0.22, 0.5, 0.18), Color(0.62, 0.82, 0.3), 0.3, -1.0, 2.0), L["ash_c"])
	# сосна: три яруса конусов
	_multi(_cyl_mesh(0.15, 0.28, 3.6, 6), Fx.mat(Color(0.4, 0.26, 0.14)), L["pine_t"])
	_multi(_cyl_mesh(0.0, 1.7, 3.4, 7), Shaders.foliage(Color(0.04, 0.24, 0.12), Color(0.15, 0.48, 0.22), 0.3, -1.7, 3.4), L["pine_1"])
	_multi(_cyl_mesh(0.0, 1.3, 2.9, 7), Shaders.foliage(Color(0.05, 0.28, 0.14), Color(0.18, 0.54, 0.25), 0.35, -1.45, 2.9), L["pine_2"])
	_multi(_cyl_mesh(0.0, 0.85, 2.3, 7), Shaders.foliage(Color(0.06, 0.32, 0.16), Color(0.22, 0.6, 0.28), 0.4, -1.15, 2.3), L["pine_3"])
	# берёза: белый ствол, жёлто-зелёная лёгкая крона
	_multi(_cyl_mesh(0.1, 0.18, 4.4, 6), Fx.mat(Color(0.93, 0.93, 0.9), 0.1), L["birch_t"])
	_multi(sph, Shaders.foliage(Color(0.45, 0.65, 0.2), Color(0.85, 0.92, 0.4), 0.4, -1.0, 2.0), L["birch_c"])
	# клён: красно-оранжевая осенняя крона
	_multi(_cyl_mesh(0.2, 0.34, 3.0, 7), Fx.mat(Color(0.3, 0.2, 0.14)), L["maple_t"])
	_multi(sph, Shaders.foliage(Color(0.65, 0.12, 0.08), Color(1.0, 0.55, 0.12), 0.25, -1.0, 2.0), L["maple_c"])

	var rocks := []
	for i in 70:
		var p2 := _spot(10.0, 220.0)
		var s2 := rng.randf_range(0.8, 2.6)
		var b2 := Basis(Vector3.UP, rng.randf() * TAU).scaled(Vector3(s2 * 1.5, s2 * 0.8, s2 * 1.5))
		rocks.append(Transform3D(b2, p2 + Vector3(0, 0.3 * s2, 0)))
	var rock_mesh := SphereMesh.new()
	rock_mesh.radius = 1.0
	rock_mesh.height = 2.0
	rock_mesh.radial_segments = 6
	rock_mesh.rings = 4
	_multi(rock_mesh, Fx.mat(Color(0.5, 0.5, 0.54), 0.0, 1.0, 0.0, 0.95), rocks)

	var fl_mesh := SphereMesh.new()
	fl_mesh.radius = 0.16
	fl_mesh.height = 0.32
	fl_mesh.radial_segments = 5
	fl_mesh.rings = 3
	var fcols := [Color(0.7, 0.3, 0.95), Color(1.0, 0.85, 0.2), Color(1.0, 0.4, 0.6), Color(0.4, 0.7, 1.0)]
	for ci in fcols.size():
		var fl := []
		for i in 120:
			var p3 := _spot(4.0, 150.0)
			fl.append(Transform3D(Basis.IDENTITY, p3 + Vector3(0, 0.2, 0)))
		_multi(fl_mesh, Fx.mat(fcols[ci], 0.8), fl)

func _build_castle() -> void:
	var cx := Terrain.CASTLE_POS.x
	var cz := Terrain.CASTLE_POS.y
	var y0 := Terrain.CASTLE_H
	var stone := Color(0.66, 0.7, 0.85)
	add_child(Fx.box(Vector3(80, 30, 28), stone, Vector3(cx, y0 + 15, cz), 0.0, 0.2, 0.6))
	var xs := [-55.0, -32.0, -12.0, 12.0, 32.0, 55.0]
	var hs := [34.0, 52.0, 70.0, 70.0, 52.0, 34.0]
	for i in xs.size():
		var x: float = xs[i]
		var th: float = hs[i]
		add_child(Fx.cylinder(5.5, 5.5, th, stone, Vector3(cx + x, y0 + th / 2.0, cz), 10))
		add_child(Fx.cylinder(0.0, 7.7, 16.0, Color(0.15, 0.4, 1.0), Vector3(cx + x, y0 + th + 8.0, cz), 10, 1.2))
		add_child(Fx.sphere(1.6, Color(0.5, 0.85, 1.0), Vector3(cx + x, y0 + th + 18.0, cz), 4.0))
	for wx in [-8.0, 0.0, 8.0]:
		add_child(Fx.box(Vector3(3, 8, 1), Color(0.5, 0.85, 1.0), Vector3(cx + wx, y0 + 12, cz + 14.2), 3.0))

func _build_sky_islands() -> void:
	var islands := [Vector3(-120, 70, -200), Vector3(150, 95, -260), Vector3(-200, 110, -300), Vector3(60, 60, -160), Vector3(220, 80, -180), Vector3(-70, 130, -380), Vector3(10, 100, -240)]
	for k in islands.size():
		var pv: Vector3 = islands[k]
		var r2 := rng.randf_range(14.0, 26.0)
		var isl := Node3D.new()
		isl.position = pv
		add_child(isl)
		isl.add_child(Fx.cylinder(r2, 0.0, r2 * 0.9, Color(0.4, 0.3, 0.24), Vector3(0, -r2 * 0.45, 0), 8))
		isl.add_child(Fx.cylinder(r2, r2, 1.6, Color(0.3, 0.62, 0.25), Vector3(0, 0.8, 0), 8))
		isl.add_child(Fx.cylinder(0.0, 3.0, 8.0, Color(0.1, 0.4, 0.2), Vector3(r2 * 0.3, 5.6, 0), 6))
		isl.add_child(Fx.cylinder(0.0, 2.2, 6.0, Color(0.12, 0.45, 0.22), Vector3(-r2 * 0.4, 4.6, r2 * 0.2), 6))
		if k < 4:
			var q := QuadMesh.new()
			q.size = Vector2(7.0, pv.y)
			var wf := MeshInstance3D.new()
			wf.mesh = q
			wf.material_override = Shaders.waterfall()
			wf.position = Vector3(0, -pv.y / 2.0, r2 - 1.0)
			wf.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			isl.add_child(wf)
		var tw := isl.create_tween().set_loops()
		tw.tween_property(isl, "position:y", pv.y + 4.0, 3.0 + k * 0.4).set_trans(Tween.TRANS_SINE)
		tw.tween_property(isl, "position:y", pv.y, 3.0 + k * 0.4).set_trans(Tween.TRANS_SINE)

	# светящийся портал
	var ppos := Vector3(80, 150, -330)
	var torus := TorusMesh.new()
	torus.inner_radius = 26.0
	torus.outer_radius = 30.0
	var ring := Fx.mesh_node(torus, Color(0.3, 0.75, 1.0), ppos, 2.5)
	ring.rotation_degrees.x = 90.0
	add_child(ring)
	var disc := Fx.cylinder(26.0, 26.0, 0.4, Color(0.4, 0.8, 1.0), ppos, 24, 1.5)
	disc.rotation_degrees.x = 90.0
	disc.material_override = Fx.mat(Color(0.4, 0.8, 1.0), 1.5, 0.35)
	add_child(disc)
	orbit = Node3D.new()
	orbit.position = ppos
	add_child(orbit)
	for i in 8:
		var a := float(i) / 8.0 * TAU
		orbit.add_child(Fx.sphere(2.0, Color(0.8, 0.95, 1.0), Vector3(cos(a) * 28.0, sin(a) * 28.0, 0), 5.0))

func _build_braziers() -> void:
	for pos2 in [Vector2(9, 9), Vector2(-9, 9), Vector2(9, -9), Vector2(-9, -9)]:
		var base := Vector3(pos2.x, Terrain.height_at(pos2.x, pos2.y), pos2.y)
		add_child(Fx.cylinder(0.12, 0.18, 1.1, Color(0.2, 0.2, 0.24), base + Vector3(0, 0.55, 0), 6))
		add_child(Fx.cylinder(0.5, 0.25, 0.4, Color(0.3, 0.3, 0.35), base + Vector3(0, 1.3, 0), 8, 0.0))
		var f := Fx.fire_emitter(2.5, 18.0, 45, 0.25)
		f.direction = Vector3.UP
		f.position = base + Vector3(0, 1.5, 0)
		add_child(f)
		f.emitting = true
		var l := OmniLight3D.new()
		l.light_color = Color(1.0, 0.6, 0.25)
		l.omni_range = 9.0
		l.light_energy = 1.6
		l.position = base + Vector3(0, 2.0, 0)
		add_child(l)
		var tw := l.create_tween().set_loops()
		tw.tween_property(l, "light_energy", 2.2, 0.15 + randf() * 0.2)
		tw.tween_property(l, "light_energy", 1.2, 0.15 + randf() * 0.2)
